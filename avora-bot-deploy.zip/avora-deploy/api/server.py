"""
FastAPI server exposing bot state to the Electron desktop app.

Endpoints (all require X-Discord-Token header = user's Discord access token):

  POST /auth/login             — exchange OAuth code, validate user is admin + in access list
  GET  /auth/me                — current user info
  GET  /bot/status             — bot online, guild, ping
  GET  /bot/guilds             — list guilds
  GET  /bot/channels           — list channels of configured guild
  POST /bot/send-message       — send message as bot to channel
  GET  /bot/settings           — get bot settings (name, avatar)
  PATCH /bot/settings          — update bot name / avatar (via Discord API)
  GET  /config                 — get full config
  PATCH /config                — update config

  GET  /tickets                — list all tickets
  GET  /tickets/{id}           — ticket details + messages
  POST /tickets/{id}/reply     — reply to a ticket from desktop
  POST /tickets/{id}/close     — close ticket

  GET  /access                 — list of allowed Discord IDs
  POST /access                 — add Discord ID
  DELETE /access/{id}          — remove Discord ID

  GET  /moderation/cases       — moderation log
  POST /moderation/warn|mute|kick|ban — perform moderation action

  GET  /leveling/leaderboard
  GET  /leveling/user/{user_id}
  GET  /leveling/rewards

  GET  /giveaways              — active giveaways
  POST /giveaways              — start giveaway
  POST /giveaways/{id}/end     — end giveaway

  GET  /reactionroles          — all reaction role messages
  POST /reactionroles
  DELETE /reactionroles/{msg_id}/{emoji}

  GET  /music/queue/{guild_id}
  POST /music/skip|stop|pause|resume

  GET  /automod/config
  PATCH /automod/config

Run via uvicorn inside the bot process (background task in setup_hook).
"""
import asyncio
import base64
import io
import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import discord
import httpx
from fastapi import FastAPI, Header, HTTPException, Request, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from utils.helpers import (
    load_config, save_config, load_json, save_json, is_admin, make_embed, now_iso
)

log = logging.getLogger("hortikbot.api")

DISCORD_API = "https://discord.com/api/v10"
ACCESS_FILE = "access.json"
_USER_CACHE: Dict[str, Any] = {}  # token-prefix → user dict (cached 30s)


def _load_access() -> Dict[str, Any]:
    return load_json(ACCESS_FILE, {"allowed_users": []})


def _save_access(data: Dict[str, Any]) -> None:
    save_json(ACCESS_FILE, data)


async def _fetch_discord_user(token: str) -> Optional[Dict[str, Any]]:
    """Get /users/@me from Discord with the user's OAuth access token.
    Cached for 30 seconds to avoid 429 rate limiting — the desktop app polls
    /auth/me every 15 seconds, without caching Discord would rate-limit us."""
    import time as _time
    cache_key = token[:32]
    now = _time.time()
    cached = _USER_CACHE.get(cache_key)
    if cached and (now - cached.get("_cached_at", 0)) < 30:
        return cached

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(
                f"{DISCORD_API}/users/@me",
                headers={"Authorization": f"Bearer {token}"},
            )
            if r.status_code != 200:
                return None
            data = r.json()
            r2 = await client.get(
                f"{DISCORD_API}/users/@me/guilds",
                headers={"Authorization": f"Bearer {token}"},
            )
            data["_guilds"] = r2.json() if r2.status_code == 200 else []
            data["_cached_at"] = now
            _USER_CACHE[cache_key] = data
            return data
    except (httpx.HTTPError, Exception):
        return None


async def _fetch_guild_member(bot_token: str, guild_id: int, user_id: int) -> Optional[Dict[str, Any]]:
    """Use the bot's token to fetch a member of the guild (to verify roles)."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(
                f"{DISCORD_API}/guilds/{guild_id}/members/{user_id}",
                headers={"Authorization": f"Bot {bot_token}"},
            )
            if r.status_code != 200:
                return None
            return r.json()
    except Exception:
        return None


async def _verify_token(request: Request) -> Dict[str, Any]:
    """Extract and validate X-Discord-Token from request headers.
    Returns the Discord user object + guilds."""
    token = request.headers.get("X-Discord-Token")
    if not token:
        raise HTTPException(401, "X-Discord-Token header missing")
    user = await _fetch_discord_user(token)
    if not user:
        raise HTTPException(401, "Invalid or expired Discord token")
    cfg = load_config()

    # Must be in the configured guild
    guild_id = cfg.get("guild_id", "")
    if not guild_id:
        raise HTTPException(500, "guild_id not configured")

    guild_id_int = int(guild_id)
    in_guild = any(int(g["id"]) == guild_id_int for g in user.get("_guilds", []))
    if not in_guild:
        # Verify via bot API
        member = await _fetch_guild_member(cfg["bot_token"], guild_id_int, int(user["id"]))
        if not member:
            raise HTTPException(403, "Вы не состоите на сервере.")

    # Check admin: either via Discord perms OR admin_role_id OR owner OR in access list
    access = _load_access()
    allowed = access.get("allowed_users", [])
    owner_id = cfg.get("owner_discord_id", "")
    is_owner = owner_id and str(user["id"]) == str(owner_id)

    # Check access list (allowed by owner)
    in_access_list = str(user["id"]) in allowed

    # Check admin on the guild via bot
    bot = request.app.state.bot
    guild = bot.get_guild(guild_id_int)
    if not guild:
        raise HTTPException(500, "Бот не на сервере.")
    member = guild.get_member(int(user["id"]))
    if not member:
        raise HTTPException(403, "Вы не на сервере бота.")

    is_admin_user = is_owner or is_admin(member, cfg) or in_access_list
    if not is_admin_user:
        raise HTTPException(403, "Недостаточно прав. Только администраторы.")

    # Also expose bot owner flag for UI
    user["_is_owner"] = bool(is_owner)
    user["_in_access_list"] = bool(in_access_list)
    return user


def create_app(bot) -> FastAPI:
    app = FastAPI(title="AVORA BOT API", version="1.0.0")
    app.state.bot = bot

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # =================== AUTH ===================
    @app.post("/auth/login")
    async def auth_login(payload: Dict[str, str] = Body(...)):
        """Exchange OAuth code for access token via Discord, then verify."""
        cfg = load_config()
        code = payload.get("code")
        if not code:
            raise HTTPException(400, "code required")
        # Exchange code
        data = {
            "client_id": cfg.get("application_id"),
            "client_secret": cfg.get("client_secret"),
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": cfg.get("redirect_uri"),
        }
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.post(f"{DISCORD_API}/oauth2/token", data=data)
            if r.status_code != 200:
                raise HTTPException(400, f"OAuth exchange failed: {r.text}")
            tokens = r.json()

        user = await _fetch_discord_user(tokens["access_token"])
        if not user:
            raise HTTPException(401, "Не удалось получить профиль Discord.")

        # Validate guild + admin
        guild_id = int(cfg.get("guild_id") or 0)
        if not guild_id:
            raise HTTPException(500, "guild_id не настроен в config.json")

        guild = bot.get_guild(guild_id)
        if not guild:
            raise HTTPException(500, "Бот не на сервере.")

        member = guild.get_member(int(user["id"]))
        if not member:
            raise HTTPException(403, "Вы не состоите на сервере бота.")

        access = _load_access()
        allowed = access.get("allowed_users", [])
        owner_id = cfg.get("owner_discord_id", "")
        is_owner = owner_id and str(user["id"]) == str(owner_id)
        in_access_list = str(user["id"]) in allowed

        is_admin_user = is_owner or is_admin(member, cfg) or in_access_list
        if not is_admin_user:
            raise HTTPException(403, "У вас нет доступа к этому приложению.")

        return {
            "access_token": tokens["access_token"],
            "refresh_token": tokens.get("refresh_token", ""),
            "expires_in": tokens.get("expires_in", 0),
            "user": {
                "id": user["id"],
                "username": user["username"],
                "global_name": user.get("global_name"),
                "avatar": user.get("avatar"),
                "discriminator": user.get("discriminator"),
            },
            "is_owner": is_owner,
            "in_access_list": in_access_list,
            "guild": {
                "id": str(guild.id),
                "name": guild.name,
                "icon": guild.icon.url if guild.icon else None,
            },
        }

    @app.get("/auth/me")
    async def auth_me(request: Request):
        user = await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        member = guild.get_member(int(user["id"])) if guild else None
        return {
            "user": {
                "id": user["id"],
                "username": user["username"],
                "global_name": user.get("global_name"),
                "avatar": user.get("avatar"),
            },
            "is_owner": user.get("_is_owner", False),
            "in_access_list": user.get("_in_access_list", False),
            "member": {
                "nick": member.nick if member else None,
                "roles": [r.id for r in member.roles] if member else [],
                "joined_at": member.joined_at.isoformat() if member and member.joined_at else None,
            } if member else None,
        }

    # =================== BOT ===================
    @app.get("/bot/status")
    async def bot_status(request: Request):
        await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        return {
            "online": bot.is_ready(),
            "username": bot.user.name if bot.user else "—",
            "user_id": str(bot.user.id) if bot.user else "",
            "avatar_url": bot.user.display_avatar.url if bot.user else "",
            "ping_ms": round(bot.latency * 1000),
            "uptime": (discord.utils.utcnow() - bot.start_time).total_seconds(),
            "guild": {
                "id": str(guild.id) if guild else "",
                "name": guild.name if guild else "",
                "member_count": guild.member_count if guild else 0,
                "icon": guild.icon.url if guild and guild.icon else "",
            },
        }

    @app.get("/bot/guilds")
    async def bot_guilds(request: Request):
        await _verify_token(request)
        return [
            {
                "id": str(g.id),
                "name": g.name,
                "icon": g.icon.url if g.icon else None,
                "member_count": g.member_count,
                "owner": g.owner_id == bot.user.id,
            }
            for g in bot.guilds
        ]

    @app.get("/bot/channels")
    async def bot_channels(request: Request, guild_id: Optional[str] = None):
        """Returns BOTH text and voice channels. UI filters by `type`."""
        await _verify_token(request)
        cfg = load_config()
        gid = int(guild_id) if guild_id else int(cfg["guild_id"])
        guild = bot.get_guild(gid)
        if not guild:
            raise HTTPException(404, "Guild not found")
        channels = []
        # Text channels
        for ch in sorted(guild.text_channels, key=lambda c: (c.category_id or 0, c.position)):
            channels.append({
                "id": str(ch.id),
                "name": ch.name,
                "type": "text",
                "category": ch.category.name if ch.category else None,
                "topic": ch.topic,
            })
        # Voice channels
        for ch in sorted(guild.voice_channels, key=lambda c: (c.category_id or 0, c.position)):
            channels.append({
                "id": str(ch.id),
                "name": ch.name,
                "type": "voice",
                "category": ch.category.name if ch.category else None,
                "topic": None,
            })
        return channels

    @app.get("/bot/roles")
    async def bot_roles(request: Request, guild_id: Optional[str] = None):
        """List all roles in the configured guild. Used by ReactionRoles, Moderation, etc."""
        await _verify_token(request)
        cfg = load_config()
        gid = int(guild_id) if guild_id else int(cfg["guild_id"])
        guild = bot.get_guild(gid)
        if not guild:
            raise HTTPException(404, "Guild not found")
        roles = []
        for r in sorted(guild.roles, key=lambda x: x.position, reverse=True):
            if r.is_default() or r.is_bot_managed() or r.is_integration():
                continue
            roles.append({
                "id": str(r.id),
                "name": r.name,
                "color": str(r.color),
                "position": r.position,
                "permissions": r.permissions.value,
            })
        return roles

    class SendMessagePayload(BaseModel):
        channel_id: str
        content: str = ""
        embed_title: Optional[str] = None
        embed_description: Optional[str] = None
        embed_color: Optional[str] = None

    @app.post("/bot/send-message")
    async def bot_send_message(request: Request, payload: SendMessagePayload):
        user = await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        channel = guild.get_channel(int(payload.channel_id)) if guild else None
        if not channel or not isinstance(channel, discord.TextChannel):
            raise HTTPException(404, "Channel not found")

        embed = None
        if payload.embed_title or payload.embed_description:
            color = int(payload.embed_color or cfg.get("embed_color", "5865F2"), 16)
            embed = discord.Embed(
                title=payload.embed_title or "",
                description=payload.embed_description or "",
                color=color,
            )
            

        try:
            msg = await channel.send(content=payload.content or None, embed=embed)
            return {"ok": True, "message_id": str(msg.id), "url": msg.jump_url}
        except discord.HTTPException as e:
            raise HTTPException(400, f"Discord error: {e.text}")

    # =================== BOT SETTINGS ===================
    class BotSettingsPayload(BaseModel):
        username: Optional[str] = None
        avatar_base64: Optional[str] = None  # data:image/png;base64,...

    @app.get("/bot/settings")
    async def bot_get_settings(request: Request):
        await _verify_token(request)
        cfg = load_config()
        return {
            "username": bot.user.name if bot.user else "",
            "avatar_url": bot.user.display_avatar.url if bot.user else "",
            "command_prefix": cfg.get("command_prefix", "!"),
            "embed_color": cfg.get("embed_color", "5865F2"),
            "application_id": cfg.get("application_id", ""),
        }

    @app.patch("/bot/settings")
    async def bot_update_settings(request: Request, payload: BotSettingsPayload):
        user = await _verify_token(request)
        cfg = load_config()
        if not user.get("_is_owner"):
            raise HTTPException(403, "Только владелец может менять настройки бота.")

        if payload.username and payload.username != bot.user.name:
            try:
                await bot.user.edit(username=payload.username[:32])
            except discord.HTTPException as e:
                raise HTTPException(400, f"Не удалось сменить имя: {e.text}")

        if payload.avatar_base64:
            try:
                # data:image/png;base64,XXXX
                if "," in payload.avatar_base64:
                    _, b64 = payload.avatar_base64.split(",", 1)
                else:
                    b64 = payload.avatar_base64
                avatar_bytes = base64.b64decode(b64)
                await bot.user.edit(avatar=avatar_bytes)
            except discord.HTTPException as e:
                raise HTTPException(400, f"Не удалось сменить аватар: {e.text}")

        return {"ok": True, "username": bot.user.name, "avatar_url": bot.user.display_avatar.url}

    # =================== CONFIG ===================
    @app.get("/config")
    async def get_config(request: Request):
        await _verify_token(request)
        cfg = load_config()
        # Mask sensitive fields
        masked = cfg.copy()
        masked["bot_token"] = "***" if cfg.get("bot_token") else ""
        masked["client_secret"] = "***" if cfg.get("client_secret") else ""
        return masked

    @app.patch("/config")
    async def patch_config(request: Request, payload: Dict[str, Any] = Body(...)):
        user = await _verify_token(request)
        if not user.get("_is_owner") and not user.get("_in_access_list"):
            raise HTTPException(403, "Недостаточно прав.")
        cfg = load_config()
        # Allow only specific keys
        allowed_keys = {
            "embed_color", "command_prefix", "welcome_channel_id", "goodbye_channel_id",
            "welcome_message", "goodbye_message", "modlog_channel_id", "autorole_id",
            "voice_master", "automod", "leveling", "admin_role_id",
        }
        for k, v in payload.items():
            if k in allowed_keys:
                cfg[k] = v
        save_config(cfg)
        return {"ok": True}

    # =================== TICKETS ===================
    # New endpoints — work with the new Tickets cog.
    # Active tickets: open channels, sync messages in real-time.
    # Closed tickets: archived transcripts, available even if bot is offline.
    @app.get("/tickets/active")
    async def tickets_active_list(request: Request):
        await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            return []
        return cog.get_active_tickets()

    @app.get("/tickets/closed")
    async def tickets_closed_list(request: Request):
        await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            return []
        return cog.get_closed_tickets()

    @app.get("/tickets/{ticket_id}")
    async def ticket_detail(request: Request, ticket_id: str):
        await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            raise HTTPException(500, "Tickets cog not loaded")
        t = cog.get_ticket(str(ticket_id))
        if not t:
            raise HTTPException(404, "Ticket not found")
        return t

    class TicketReplyPayload(BaseModel):
        content: str
        staff_name: Optional[str] = None

    @app.post("/tickets/{ticket_id}/reply")
    async def ticket_reply(request: Request, ticket_id: str, payload: TicketReplyPayload):
        user = await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            raise HTTPException(500, "Tickets cog not loaded")
        staff_name = payload.staff_name or user.get("global_name") or user.get("username") or "Администратор"
        result = await cog.send_reply_from_app(
            str(ticket_id), payload.content, author_name=staff_name
        )
        if not result.get("ok"):
            raise HTTPException(400, result.get("error", "Unknown error"))
        return result

    @app.post("/tickets/{ticket_id}/close")
    async def ticket_close_endpoint(request: Request, ticket_id: str):
        user = await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            raise HTTPException(500, "Tickets cog not loaded")
        staff_name = user.get("global_name") or user.get("username") or "Администратор"
        result = await cog.close_ticket_from_app(str(ticket_id), closed_by_name=staff_name)
        if not result.get("ok"):
            raise HTTPException(400, result.get("error", "Unknown error"))
        return result

    @app.delete("/tickets/{ticket_id}")
    async def ticket_delete(request: Request, ticket_id: str):
        """Permanently delete a closed ticket from the archive."""
        await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            raise HTTPException(500, "Tickets cog not loaded")
        result = await cog.delete_closed_ticket(str(ticket_id))
        if not result.get("ok"):
            raise HTTPException(400, result.get("error", "Unknown error"))
        return result

    class TicketPanelPayload(BaseModel):
        channel_id: int
        title: Optional[str] = "Поддержка"
        description: Optional[str] = "Нажмите кнопку ниже, чтобы создать тикет с администратором."

    @app.post("/tickets/panel")
    async def ticket_create_panel(request: Request, payload: TicketPanelPayload):
        """Create a ticket panel message in a specific channel (called from app)."""
        await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            raise HTTPException(500, "Tickets cog not loaded")
        result = await cog.create_panel_in_channel(
            payload.channel_id, payload.title or "Поддержка",
            payload.description or "Нажмите кнопку ниже, чтобы создать тикет с администратором."
        )
        if not result.get("ok"):
            raise HTTPException(400, result.get("error", "Unknown error"))
        return result

    # Legacy /tickets endpoint — keep for backward compat with old UI versions
    @app.get("/tickets")
    async def tickets_legacy_list(request: Request, status: Optional[str] = None):
        await _verify_token(request)
        cog = bot.get_cog("Tickets")
        if cog is None:
            return []
        if status == "closed":
            return cog.get_closed_tickets()
        if status == "active":
            return cog.get_active_tickets()
        # No status filter — return both
        return cog.get_active_tickets() + cog.get_closed_tickets()

    # =================== ACCESS ===================
    @app.get("/access")
    async def access_list(request: Request):
        await _verify_token(request)
        access = _load_access()
        return access.get("allowed_users", [])

    class AccessAddPayload(BaseModel):
        user_id: str
        note: Optional[str] = None

    @app.post("/access")
    async def access_add(request: Request, payload: AccessAddPayload):
        user = await _verify_token(request)
        if not user.get("_is_owner"):
            raise HTTPException(403, "Только владелец может выдавать доступ.")
        access = _load_access()
        lst = access.setdefault("allowed_users", [])
        if payload.user_id not in [x["user_id"] if isinstance(x, dict) else x for x in lst]:
            lst.append({"user_id": payload.user_id, "note": payload.note or ""})
        _save_access(access)
        return {"ok": True, "allowed_users": lst}

    @app.delete("/access/{user_id}")
    async def access_remove(request: Request, user_id: str):
        user = await _verify_token(request)
        if not user.get("_is_owner"):
            raise HTTPException(403, "Только владелец может убирать доступ.")
        access = _load_access()
        lst = access.get("allowed_users", [])
        new_lst = [x for x in lst if (x.get("user_id") if isinstance(x, dict) else x) != user_id]
        access["allowed_users"] = new_lst
        _save_access(access)
        return {"ok": True, "allowed_users": new_lst}

    # =================== MODERATION ===================
    @app.get("/moderation/cases")
    async def mod_cases(request: Request, limit: int = 50):
        await _verify_token(request)
        db = load_json("moderation.json", {"cases": []})
        cases = db.get("cases", [])
        cases = cases[-limit:]
        cases.reverse()
        return cases

    class ModActionPayload(BaseModel):
        user_id: str
        reason: str = "Не указана"
        duration: Optional[str] = None
        delete_days: Optional[int] = 1

    @app.post("/moderation/warn")
    async def mod_warn_api(request: Request, payload: ModActionPayload):
        user = await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        member = guild.get_member(int(payload.user_id)) if guild else None
        if not member:
            raise HTTPException(404, "Member not found")
        db = load_json("moderation.json", {"cases": [], "counter": 0})
        db["counter"] = db.get("counter", 0) + 1
        case = {
            "id": db["counter"],
            "action": "warn",
            "user_id": str(member.id),
            "user_name": str(member),
            "moderator_id": str(user["id"]),
            "moderator_name": user.get("username", "Desktop"),
            "reason": payload.reason,
            "duration": None,
            "timestamp": now_iso(),
        }
        db.setdefault("cases", []).append(case)
        save_json("moderation.json", db)
        try:
            await member.send(f"⚠️ Вам выдано предупреждение на сервере **{guild.name}**.\nПричина: {payload.reason}")
        except discord.Forbidden:
            pass
        return {"ok": True, "case": case}

    @app.post("/moderation/mute")
    async def mod_mute_api(request: Request, payload: ModActionPayload):
        await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        member = guild.get_member(int(payload.user_id)) if guild else None
        if not member:
            raise HTTPException(404, "Member not found")
        from utils.helpers import parse_duration
        from datetime import timedelta
        seconds = parse_duration(payload.duration or "10m")
        if not seconds:
            raise HTTPException(400, "Invalid duration")
        try:
            # discord.utils.utcnow() returns timezone-aware datetime
            # timedelta is the standard library one — `discord.utils.timedelta`
            # doesn't exist, that's what was causing HTTP 500.
            await member.timeout(
                discord.utils.utcnow() + timedelta(seconds=seconds),
                reason=payload.reason or "Muted via AVORA BOT",
            )
        except discord.Forbidden:
            raise HTTPException(403, (
                "У бота нет прав на мут. Нужно: "
                "1) Бот имеет разрешение 'Timeout Members' (MODERATE_MEMBERS) на сервере. "
                "2) Роль бота ВЫШЕ роли замьючиваемого пользователя. "
                "Зайдите в Настройки сервера → Роли → перетащите роль бота выше."
            ))
        except discord.HTTPException as e:
            raise HTTPException(500, f"Discord error: {e.text}")
        return {"ok": True}

    @app.post("/moderation/kick")
    async def mod_kick_api(request: Request, payload: ModActionPayload):
        await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        member = guild.get_member(int(payload.user_id)) if guild else None
        if not member:
            raise HTTPException(404, "Member not found")
        try:
            await member.kick(reason=payload.reason)
        except discord.Forbidden:
            raise HTTPException(403, "No permission")
        return {"ok": True}

    @app.post("/moderation/ban")
    async def mod_ban_api(request: Request, payload: ModActionPayload):
        await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        member = guild.get_member(int(payload.user_id)) if guild else None
        if not member:
            raise HTTPException(404, "Member not found")
        try:
            await member.ban(reason=payload.reason, delete_message_days=payload.delete_days or 1)
        except discord.Forbidden:
            raise HTTPException(403, "No permission")
        return {"ok": True}

    # =================== LEVELING ===================
    @app.get("/giveaways")
    async def giveaways_list_api(request: Request):
        await _verify_token(request)
        db = load_json("giveaways.json", {"active": {}, "ended": []})
        return {"active": list(db.get("active", {}).values()), "ended": db.get("ended", [])[-10:]}

    class StartGiveawayPayload(BaseModel):
        channel_id: str
        duration: str
        winners: int
        prize: str
        description: Optional[str] = None

    @app.post("/giveaways")
    async def start_giveaway_api(request: Request, payload: StartGiveawayPayload):
        await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        channel = guild.get_channel(int(payload.channel_id)) if guild else None
        if not channel or not isinstance(channel, discord.TextChannel):
            raise HTTPException(404, "Channel not found")
        from cogs.giveaways import GiveawayView
        from utils.helpers import parse_duration
        seconds = parse_duration(payload.duration)
        if not seconds:
            raise HTTPException(400, "Invalid duration")
        ends_at = datetime.utcnow() + (datetime.utcnow() - datetime.utcnow())  # placeholder
        from datetime import timedelta
        ends_at = datetime.utcnow() + timedelta(seconds=seconds)
        embed = make_embed(
            title=f"🎉 Розыгрыш: {payload.prize}",
            description=payload.description or "Нажмите кнопку ниже, чтобы участвовать!",
            fields=[
                {"name": "Победителей", "value": f"**{payload.winners}**", "inline": True},
                {"name": "Завершится", "value": f"<t:{int(ends_at.timestamp())}:R>", "inline": True},
                {"name": "Участников", "value": "**0**", "inline": True},
            ],
            color=0xFEE75C,
        )
        msg = await channel.send(embed=embed, view=GiveawayView())
        db = load_json("giveaways.json", {"active": {}, "ended": []})
        db.setdefault("active", {})[str(msg.id)] = {
            "message_id": str(msg.id),
            "channel_id": str(channel.id),
            "guild_id": str(guild.id),
            "prize": payload.prize,
            "winners": payload.winners,
            "description": payload.description,
            "organizer_id": "desktop",
            "participants": [],
            "ends_at": ends_at.isoformat(),
            "created_at": now_iso(),
        }
        save_json("giveaways.json", db)
        return {"ok": True, "message_id": str(msg.id), "url": msg.jump_url}

    @app.post("/giveaways/{msg_id}/end")
    async def end_giveaway_api(request: Request, msg_id: str):
        await _verify_token(request)
        db = load_json("giveaways.json", {"active": {}, "ended": []})
        g = db.get("active", {}).get(msg_id)
        if not g:
            raise HTTPException(404, "Giveaway not found")
        from cogs.giveaways import GiveawaysCog
        cog = bot.get_cog("GiveawaysCog")
        if cog:
            await cog._end_giveaway(msg_id, g)
        del db["active"][msg_id]
        db.setdefault("ended", []).append(g)
        save_json("giveaways.json", db)
        return {"ok": True}

    # =================== REACTION ROLES ===================
    @app.get("/reactionroles")
    async def rr_list_api(request: Request):
        await _verify_token(request)
        db = load_json("reaction_roles.json", {"messages": {}})
        return list(db.get("messages", {}).values())

    class CreateRRPayload(BaseModel):
        channel_id: str
        title: str
        description: str
        reactions: List[Dict[str, str]]  # [{emoji, role_id}]

    @app.post("/reactionroles")
    async def rr_create_api(request: Request, payload: CreateRRPayload):
        await _verify_token(request)
        cfg = load_config()
        guild = bot.get_guild(int(cfg["guild_id"]))
        channel = guild.get_channel(int(payload.channel_id)) if guild else None
        if not channel or not isinstance(channel, discord.TextChannel):
            raise HTTPException(404, "Channel not found")
        embed = make_embed(title=payload.title, description=payload.description)
        msg = await channel.send(embed=embed)
        db = load_json("reaction_roles.json", {"messages": {}})
        msg_entry = {
            "channel_id": str(channel.id),
            "guild_id": str(guild.id),
            "reactions": {},
            "remove_reaction": True,
        }
        for r in payload.reactions:
            emoji = r.get("emoji")
            role_id = r.get("role_id")
            if emoji and role_id:
                try:
                    await msg.add_reaction(emoji)
                except discord.HTTPException:
                    pass
                msg_entry["reactions"][emoji] = str(role_id)
        db.setdefault("messages", {})[str(msg.id)] = msg_entry
        save_json("reaction_roles.json", db)
        return {"ok": True, "message_id": str(msg.id), "url": msg.jump_url}

    # =================== MUSIC ===================
    @app.get("/music/queue/{guild_id}")
    async def music_queue_api(request: Request, guild_id: int):
        await _verify_token(request)
        cog = bot.get_cog("MusicCog")
        if not cog:
            raise HTTPException(500, "Music cog not loaded")
        state = cog.get_state(guild_id)
        return {
            "current": {"title": state.current.title, "url": state.current.url} if state.current else None,
            "queue": state.queue[:20],
            "volume": int(state.volume * 100),
            "loop_mode": state.loop_mode,
        }

    # =================== AUTOMOD ===================
    @app.get("/automod/config")
    async def am_get_api(request: Request):
        await _verify_token(request)
        cfg = load_config()
        return cfg.get("automod", {})

    @app.patch("/automod/config")
    async def am_patch_api(request: Request, payload: Dict[str, Any] = Body(...)):
        await _verify_token(request)
        cfg = load_config()
        am = cfg.setdefault("automod", {})
        for k, v in payload.items():
            if k in {"enabled", "anti_spam", "anti_caps", "anti_links", "anti_invites",
                     "spam_threshold", "caps_threshold", "ignored_channels", "ignored_roles"}:
                am[k] = v
        save_config(cfg)
        return {"ok": True}

    return app


async def run_api_server(bot):
    """Background task that runs uvicorn.
    In cloud mode (BOT_TOKEN env var set), binds to 0.0.0.0 and uses PORT env var.
    In local mode, binds to 127.0.0.1:8721 (only accessible from desktop app).
    """
    import uvicorn
    import os
    cfg = load_config()
    # Cloud platforms (Render, Railway, Heroku) set PORT env var.
    # Use it if present, otherwise fall back to config.
    port = int(os.environ.get("PORT", cfg.get("api_port", 8721)))
    # In cloud mode, bind to 0.0.0.0 (all interfaces) so the platform can
    # route traffic. In local mode, bind to 127.0.0.1 (localhost only).
    if os.environ.get("BOT_TOKEN"):
        host = "0.0.0.0"
    else:
        host = cfg.get("api_host", "127.0.0.1")
    app = create_app(bot)
    config = uvicorn.Config(app, host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)
    log.info("API server starting on http://%s:%d", host, port)
    try:
        await server.serve()
    except asyncio.CancelledError:
        log.info("API server cancelled")
    except Exception as e:
        log.exception("API server error: %s", e)


class APICog:
    """Loaded as a discord.py extension."""

    @staticmethod
    async def setup(bot):
        bot.api_task = asyncio.create_task(run_api_server(bot))


# Loaded as a cog extension
from discord.ext import commands


class APIExtensionCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.api_task = asyncio.create_task(run_api_server(bot))

    def cog_unload(self):
        self.api_task.cancel()


async def setup(bot: commands.Bot):
    await bot.add_cog(APIExtensionCog(bot))
