"""api package — FastAPI bridge for desktop app <-> bot."""
