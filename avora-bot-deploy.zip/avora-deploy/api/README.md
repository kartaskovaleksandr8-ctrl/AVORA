# API server — FastAPI bridge между ботом и десктоп-приложением

Запускается автоматически внутри процесса бота (см. `bot.py` → `setup_hook` → `api.server`).

## Endpoints

Все запросы (кроме `/auth/login`) требуют заголовок `X-Discord-Token: <access_token>`.

### Аутентификация
- `POST /auth/login` — обмен OAuth-кода на access_token + проверка прав
- `GET /auth/me` — информация о текущем пользователе

### Бот
- `GET /bot/status` — состояние бота (онлайн, пинг, аптайм, гильдия)
- `GET /bot/guilds` — список серверов бота
- `GET /bot/channels` — каналы настроенной гильдии
- `POST /bot/send-message` — отправить сообщение от имени бота
- `GET /bot/settings` — имя, аватар, цвет
- `PATCH /bot/settings` — сменить имя/аватар (только владелец)

### Конфиг
- `GET /config` — текущий config.json (с замаскированными секретами)
- `PATCH /config` — обновить разрешённые ключи

### Тикеты
- `GET /tickets` — список всех тикетов
- `GET /tickets/{id}` — детали тикета + сообщения
- `POST /tickets/{id}/reply` — ответить от имени поддержки
- `POST /tickets/{id}/close` — закрыть тикет

### Доступ
- `GET /access` — список разрешённых Discord ID
- `POST /access` — добавить (только владелец)
- `DELETE /access/{id}` — убрать (только владелец)

### Модерация
- `GET /moderation/cases` — лог
- `POST /moderation/warn|mute|kick|ban` — выполнить действие

### Leveling
- `GET /leveling/leaderboard`
- `GET /leveling/rewards`

### Giveaways
- `GET /giveaways` — активные + завершённые
- `POST /giveaways` — создать
- `POST /giveaways/{id}/end` — завершить досрочно

### Reaction Roles
- `GET /reactionroles`
- `POST /reactionroles` — создать сообщение с реакциями

### Музыка
- `GET /music/queue/{guild_id}` — текущий трек + очередь

### AutoMod
- `GET /automod/config`
- `PATCH /automod/config`
