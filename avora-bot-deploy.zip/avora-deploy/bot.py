"""
AVORA BOT — main entry point.

Run with:  python bot.py        (development)
       or:  bundled with Electron app (embedded python.exe + bot.py)

Requires:  pip install -r requirements.txt (already bundled in production)
Config:    config.json next to bot.py
"""
import asyncio
import logging
import logging.handlers
import sys
import os
from pathlib import Path

# --- Ensure the bot root directory is on sys.path ---------------------------
# When running with the embedded Python distribution (python.exe from
# python/ subfolder), the script's directory is NOT automatically added to
# sys.path. The python311._pth file adds ".." (relative to python/) which
# should resolve to the bot root — but to be safe, we also add it explicitly
# here based on the actual location of this bot.py file.
_THIS = Path(__file__).resolve().parent
_BOT_ROOT = _THIS  # bot.py is in the bot root
if str(_BOT_ROOT) not in sys.path:
    sys.path.insert(0, str(_BOT_ROOT))

import discord
from discord.ext import commands

from utils.helpers import load_config, save_config, load_json, save_json, APP_DIR

# Force line-buffered stdout/stderr so Electron can read logs in real time
try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass


# --- File logging -----------------------------------------------------------
# Write all bot logs to %LOCALAPPDATA%\AVORA BOT\bot.log
# (mirrored by the Electron main process, but we also write here so the file
# is always up to date even if the IPC link breaks).
def _get_log_file_path() -> Path:
    """Find a writable location for bot.log."""
    # 1. %LOCALAPPDATA%\AVORA BOT\bot.log (production on Windows)
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        p = Path(local_app_data) / "AVORA BOT"
        try:
            p.mkdir(parents=True, exist_ok=True)
            return p / "bot.log"
        except Exception:
            pass
    # 2. Next to bot.py (development)
    try:
        return APP_DIR / "bot.log"
    except Exception:
        pass
    # 3. Temp dir
    return Path("/tmp/avora_bot.log") if sys.platform != "win32" else Path(os.environ.get("TEMP", "C:\\")) / "avora_bot.log"


LOG_FILE = _get_log_file_path()

# Set up logging — write to BOTH stdout (for Electron IPC) and the log file.
_file_handler = logging.handlers.RotatingFileHandler(
    LOG_FILE,
    maxBytes=2 * 1024 * 1024,  # 2 MB
    backupCount=3,
    encoding="utf-8",
)
_file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        _file_handler,
    ],
)
log = logging.getLogger("avora_bot")

log.info("=" * 60)
log.info("AVORA BOT — starting up")
log.info("Bot root dir: %s", _BOT_ROOT)
log.info("Log file: %s", LOG_FILE)
log.info("Python: %s %s", sys.version.split()[0], sys.platform)
log.info("argv: %s", sys.argv)
log.info("cwd: %s", os.getcwd())
log.info("=" * 60)

intents = discord.Intents.all()
intents.message_content = True
intents.members = True
intents.voice_states = True
intents.presences = True
intents.reactions = True


class AvoraBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or("!"),
            intents=intents,
            help_command=commands.DefaultHelpCommand(dm_help=True),
        )
        self.config = load_config()
        self.start_time = discord.utils.utcnow()

    async def setup_hook(self) -> None:
        """Load cogs + start FastAPI server in background."""
        cogs_dir = _BOT_ROOT / "cogs"
        log.info("Loading cogs from %s", cogs_dir)
        for cog_file in sorted(cogs_dir.glob("*.py")):
            if cog_file.stem.startswith("_"):
                continue
            module = f"cogs.{cog_file.stem}"
            try:
                await self.load_extension(module)
                log.info("Loaded cog: %s", module)
            except Exception as exc:
                log.exception("Failed to load %s: %s", module, exc)

        # Load FastAPI bridge
        try:
            await self.load_extension("api.server")
            log.info("Loaded API server (api.server)")
        except Exception as exc:
            log.exception("Failed to load API server: %s", exc)

    async def on_ready(self):
        log.info("========================================")
        log.info(" BOT IS READY")
        log.info(" Logged in as: %s", self.user)
        log.info(" Bot user ID:  %s", self.user.id)
        log.info(" Connected to %d guild(s)", len(self.guilds))
        log.info("========================================")
        try:
            synced = await self.tree.sync()
            log.info("Synced %d slash commands", len(synced))
        except Exception as exc:
            log.exception("Slash sync failed: %s", exc)
        log.info("API server should be running on http://127.0.0.1:8721")


def main():
    # CLOUD MODE: if BOT_TOKEN env var is set, use environment variables
    # instead of config.json. This allows deployment on Render/Railway/etc.
    # without needing a config.json file.
    env_token = os.environ.get("BOT_TOKEN", "")
    if env_token:
        log.info("🌐 CLOUD MODE: using environment variables for config")
        # Build config from env vars
        cloud_cfg = {
            "bot_token": env_token,
            "application_id": os.environ.get("APPLICATION_ID", ""),
            "client_secret": os.environ.get("CLIENT_SECRET", ""),
            "redirect_uri": os.environ.get("REDIRECT_URI", "http://localhost:8722/auth/callback"),
            "guild_id": os.environ.get("GUILD_ID", ""),
            "admin_role_id": os.environ.get("ADMIN_ROLE_ID", ""),
            "owner_discord_id": os.environ.get("OWNER_DISCORD_ID", ""),
            "command_prefix": os.environ.get("COMMAND_PREFIX", "!"),
            "api_host": os.environ.get("API_HOST", "0.0.0.0"),
            "api_port": int(os.environ.get("PORT", os.environ.get("API_PORT", "8721"))),
            "oauth_port": int(os.environ.get("OAUTH_PORT", "8722")),
            "embed_color": os.environ.get("EMBED_COLOR", "5865F2"),
            "welcome_channel_id": os.environ.get("WELCOME_CHANNEL_ID", ""),
            "goodbye_channel_id": os.environ.get("GOODBYE_CHANNEL_ID", ""),
            "welcome_message": os.environ.get("WELCOME_MESSAGE", "Добро пожаловать, {user}!"),
            "goodbye_message": os.environ.get("GOODBYE_MESSAGE", "Прощай, {user}!"),
            "voice_master": {"enabled": False, "trigger_channel_id": "", "category_id": "", "name_template": "🔊 {user}'s channel"},
            "automod": {"enabled": False, "anti_spam": True, "anti_caps": False, "anti_links": False, "anti_invites": True, "spam_threshold": 5, "caps_threshold": 70, "ignored_channels": [], "ignored_roles": []},
            "tickets_category_id": os.environ.get("TICKETS_CATEGORY_ID", ""),
        }
        # Override the load_config function to return our cloud config
        import utils.helpers as _helpers
        _helpers.load_config = lambda: cloud_cfg
        # Also set APP_DIR to current directory (cloud filesystem)
        _helpers.APP_DIR = _THIS
        _helpers.DB_DIR = _THIS / "database"
        _helpers.DB_DIR.mkdir(parents=True, exist_ok=True)
        cfg = cloud_cfg
        token = env_token
    else:
        # LOCAL MODE: use config.json (desktop app)
        cfg = load_config()
        token = cfg.get("bot_token", "")
        log.info("Config loaded from %s", APP_DIR / "config.json")
        log.info("Config keys: %s", list(cfg.keys()) if cfg else "(empty)")
        if not cfg:
            log.error("========================================")
            log.error(" Config not found or empty!")
            log.error(" Expected location: %s", APP_DIR / "config.json")
            log.error(" Or set BOT_TOKEN environment variable for cloud mode.")
            log.error("========================================")
            sys.exit(1)

    if not token or token.startswith("PASTE_"):
        log.error("========================================")
        log.error(" Bot token not configured!")
        log.error(" Set BOT_TOKEN env var (cloud) or edit config.json (local).")
        log.error("========================================")
        sys.exit(1)

    log.info("Bot token length: %d characters", len(token))
    log.info("Starting Discord connection...")

    bot = AvoraBot()
    try:
        bot.run(token, reconnect=True)
    except KeyboardInterrupt:
        log.info("Shutting down (Ctrl+C)...")
    except Exception as exc:
        log.exception("Bot crashed: %s", exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
