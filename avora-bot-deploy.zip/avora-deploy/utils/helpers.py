"""
Utils module: helpers for JSON storage, embeds, common functions.
"""
import json
import os
import sys
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, List, Optional

import discord


def _get_app_dir() -> Path:
    """
    Determine the real application directory (the folder containing bot.py,
    config.json, cogs/, utils/, api/, database/).

    - When running as a normal Python script (development OR embedded python.exe):
      parent of this file's parent (utils/.. = bot root).
    - When running as a PyInstaller bundle (bot.exe): the folder containing bot.exe.
      `sys.frozen` is set by PyInstaller; `sys.executable` points to the .exe.
    - The path is resolved to absolute to avoid issues with relative __file__
      when the embedded Python is invoked with cwd=bot root and a relative
      script path.
    """
    if getattr(sys, "frozen", False):
        # Running as bundled exe (PyInstaller)
        return Path(sys.executable).parent.resolve()
    # Running as a Python script — utils/helpers.py is one level below bot root.
    return Path(__file__).resolve().parent.parent.resolve()


APP_DIR = _get_app_dir()
DB_DIR = APP_DIR / "database"


def _ensure_db_dir() -> None:
    DB_DIR.mkdir(parents=True, exist_ok=True)


def load_json(file_name: str, default: Any = None) -> Any:
    """Load JSON from database/<file_name>. Returns default if missing/invalid."""
    _ensure_db_dir()
    path = DB_DIR / file_name
    if not path.exists():
        save_json(file_name, default if default is not None else {})
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return default if default is not None else {}


def save_json(file_name: str, data: Any) -> None:
    """Save JSON to database/<file_name> atomically."""
    _ensure_db_dir()
    path = DB_DIR / file_name
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    os.replace(tmp, path)


def load_config() -> Dict[str, Any]:
    """Load the main config.json."""
    config_path = APP_DIR / "config.json"
    if not config_path.exists():
        return {}
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg: Dict[str, Any]) -> None:
    """Save config.json."""
    config_path = APP_DIR / "config.json"
    tmp = config_path.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False, default=str)
    os.replace(tmp, config_path)


def make_embed(
    title: str = "",
    description: str = "",
    color: Optional[int] = None,
    footer: str = "",
    author: Optional[discord.User] = None,
    fields: Optional[List[Dict[str, Any]]] = None,
) -> discord.Embed:
    """Build a standardized Discord embed.
    NOTE: footer and timestamp are NOT set by default — the user requested
    that bot messages don't show any 'Вчера, в 21:52' / 'Отправлено через ...'
    text below them. Pass `footer="..."` explicitly to add one (rarely needed)."""
    if color is None:
        cfg = load_config()
        color = int(cfg.get("embed_color", "5865F2"), 16)
    embed = discord.Embed(title=title, description=description, color=color)
    # Intentionally NOT setting embed.timestamp — that's what produces
    # the "Вчера в 21:52" footer in Discord automatically.
    if author:
        embed.set_author(name=author.name, icon_url=author.display_avatar.url)
    if fields:
        for field in fields:
            embed.add_field(
                name=field.get("name", "—"),
                value=field.get("value", "—"),
                inline=field.get("inline", False),
            )
    return embed


async def safe_send(channel: discord.abc.Messageable, content: str = "", embed: Optional[discord.Embed] = None) -> Optional[discord.Message]:
    """Send message, swallow common errors."""
    try:
        return await channel.send(content=content, embed=embed)
    except (discord.Forbidden, discord.HTTPException):
        return None


def member_has_role(member: discord.Member, role_id: int) -> bool:
    return any(r.id == role_id for r in member.roles)


def is_admin(member: discord.Member, cfg: Dict[str, Any]) -> bool:
    """Check if member is admin (Discord perms OR admin_role_id OR owner)."""
    owner_id = cfg.get("owner_discord_id", "")
    if owner_id and str(member.id) == str(owner_id):
        return True
    admin_role = cfg.get("admin_role_id", "")
    if admin_role and member_has_role(member, int(admin_role)):
        return True
    return member.guild_permissions.administrator


def parse_duration(text: str) -> Optional[int]:
    """Parse strings like '30s', '10m', '2h', '1d' into seconds."""
    if not text:
        return None
    text = text.lower().strip()
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    if text[-1] not in units:
        try:
            return int(text)
        except ValueError:
            return None
    try:
        return int(text[:-1]) * units[text[-1]]
    except (ValueError, KeyError):
        return None


def format_duration(seconds: int) -> str:
    """Format seconds into '1d 2h 3m 4s' style."""
    if seconds <= 0:
        return "0s"
    parts = []
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds:
        parts.append(f"{seconds}s")
    return " ".join(parts)


def now_iso() -> str:
    return datetime.utcnow().isoformat()
