"""
Moderation cog.

Slash commands:
  /warn <user> [reason]
  /warnings <user>
  /mute <user> <duration> [reason]
  /unmute <user>
  /kick <user> [reason]
  /ban <user> [reason] [delete_days]
  /unban <user_id>
  /clear <count> [user]
  /modlog [user]
  /slowmode <seconds>

Logs everything to database/moderation.json.
"""
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional
from datetime import timedelta

from utils.helpers import (
    load_json, save_json, make_embed, is_admin, parse_duration, format_duration,
    now_iso, load_config, member_has_role
)

DB_FILE = "moderation.json"


class ModerationCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.db = load_json(DB_FILE, {"cases": [], "counter": 0, "mutes": {}})

    def _save(self):
        save_json(DB_FILE, self.db)

    def _new_case(self, action: str, user_id: str, user_name: str, mod_id: str, mod_name: str, reason: str, duration: Optional[str] = None) -> int:
        self.db["counter"] = self.db.get("counter", 0) + 1
        case_id = self.db["counter"]
        case = {
            "id": case_id,
            "action": action,
            "user_id": user_id,
            "user_name": user_name,
            "moderator_id": mod_id,
            "moderator_name": mod_name,
            "reason": reason,
            "duration": duration,
            "timestamp": now_iso(),
        }
        self.db.setdefault("cases", []).append(case)
        self._save()
        return case_id

    async def _send_modlog(self, guild: discord.Guild, embed: discord.Embed):
        cfg = load_config()
        log_channel_id = cfg.get("modlog_channel_id")
        if not log_channel_id:
            return
        channel = guild.get_channel(int(log_channel_id))
        if channel:
            try:
                await channel.send(embed=embed)
            except discord.HTTPException:
                pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        # Track for ban detection if needed; nothing required here
        pass

    mod_group = app_commands.Group(name="mod", description="Команды модерации")

    @mod_group.command(name="warn", description="Выдать предупреждение")
    @app_commands.describe(user="Кому", reason="Причина")
    @app_commands.default_permissions(manage_messages=True)
    async def mod_warn(self, interaction: discord.Interaction, user: discord.Member, reason: str = "Не указана"):
        cfg = load_config()
        if not is_admin(interaction.user, cfg) and interaction.user.top_role <= user.top_role:
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        case_id = self._new_case(
            "warn", str(user.id), str(user), str(interaction.user.id), str(interaction.user), reason
        )
        embed = make_embed(
            title="⚠️ Предупреждение",
            description=f"**{user.mention}** получил предупреждение.",
            fields=[
                {"name": "Модератор", "value": interaction.user.mention, "inline": True},
                {"name": "Причина", "value": reason, "inline": False},
                {"name": "Case ID", "value": f"#{case_id}", "inline": True},
            ],
            color=0xFEE75C,
        )
        await self._send_modlog(interaction.guild, embed)
        await interaction.response.send_message(embed=embed)
        try:
            await user.send(f"Вам выдано предупреждение на сервере **{interaction.guild.name}**.\nПричина: {reason}")
        except discord.Forbidden:
            pass

    @mod_group.command(name="warnings", description="Посмотреть предупреждения пользователя")
    @app_commands.describe(user="Кто")
    async def mod_warnings(self, interaction: discord.Interaction, user: discord.Member):
        cases = [c for c in self.db.get("cases", []) if c["action"] == "warn" and c["user_id"] == str(user.id)]
        if not cases:
            await interaction.response.send_message(f"У {user.mention} нет предупреждений.", ephemeral=True)
            return
        embed = make_embed(title=f"⚠️ Предупреждения — {user}", description=f"Всего: **{len(cases)}**")
        for c in cases[-10:]:
            embed.add_field(
                name=f"#{c['id']} — {c['timestamp'][:10]}",
                value=f"Модератор: <@{c['moderator_id']}>\nПричина: {c['reason']}",
                inline=False,
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @mod_group.command(name="mute", description="Замутить пользователя (timeout)")
    @app_commands.describe(
        user="Кого",
        duration="Длительность: 30s, 10m, 2h, 1d (макс 28d)",
        reason="Причина",
    )
    @app_commands.default_permissions(moderate_members=True)
    async def mod_mute(
        self,
        interaction: discord.Interaction,
        user: discord.Member,
        duration: str,
        reason: str = "Не указана",
    ):
        cfg = load_config()
        if not is_admin(interaction.user, cfg) and interaction.user.top_role <= user.top_role:
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        seconds = parse_duration(duration)
        if not seconds or seconds > 28 * 86400:
            await interaction.response.send_message("❌ Длительность некорректна (макс 28d).", ephemeral=True)
            return
        try:
            await user.timeout(discord.utils.utcnow() + timedelta(seconds=seconds), reason=reason)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Нет прав на мут.", ephemeral=True)
            return
        case_id = self._new_case(
            "mute", str(user.id), str(user), str(interaction.user.id), str(interaction.user), reason, duration
        )
        embed = make_embed(
            title="🔇 Замьютен",
            description=f"{user.mention} замучен на **{format_duration(seconds)}**.",
            fields=[
                {"name": "Модератор", "value": interaction.user.mention, "inline": True},
                {"name": "Причина", "value": reason, "inline": False},
                {"name": "Case ID", "value": f"#{case_id}", "inline": True},
            ],
            color=0xED4245,
        )
        await self._send_modlog(interaction.guild, embed)
        await interaction.response.send_message(embed=embed)

    @mod_group.command(name="unmute", description="Размутить пользователя")
    @app_commands.describe(user="Кого")
    @app_commands.default_permissions(moderate_members=True)
    async def mod_unmute(self, interaction: discord.Interaction, user: discord.Member):
        try:
            await user.timeout(None, reason=f"Размут от {interaction.user}")
        except discord.Forbidden:
            await interaction.response.send_message("❌ Нет прав.", ephemeral=True)
            return
        case_id = self._new_case(
            "unmute", str(user.id), str(user), str(interaction.user.id), str(interaction.user), "Размут"
        )
        embed = make_embed(
            title="🔊 Размучен",
            description=f"{user.mention} размучен.",
            color=0x57F287,
        )
        await self._send_modlog(interaction.guild, embed)
        await interaction.response.send_message(embed=embed)

    @mod_group.command(name="kick", description="Выгнать пользователя")
    @app_commands.describe(user="Кого", reason="Причина")
    @app_commands.default_permissions(kick_members=True)
    async def mod_kick(self, interaction: discord.Interaction, user: discord.Member, reason: str = "Не указана"):
        cfg = load_config()
        if not is_admin(interaction.user, cfg) and interaction.user.top_role <= user.top_role:
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        try:
            await user.kick(reason=f"{interaction.user}: {reason}")
        except discord.Forbidden:
            await interaction.response.send_message("❌ Нет прав.", ephemeral=True)
            return
        case_id = self._new_case(
            "kick", str(user.id), str(user), str(interaction.user.id), str(interaction.user), reason
        )
        embed = make_embed(
            title="👢 Кик",
            description=f"{user.mention} кикнут.",
            fields=[
                {"name": "Модератор", "value": interaction.user.mention, "inline": True},
                {"name": "Причина", "value": reason, "inline": False},
            ],
            color=0xED4245,
        )
        await self._send_modlog(interaction.guild, embed)
        await interaction.response.send_message(embed=embed)

    @mod_group.command(name="ban", description="Забанить пользователя")
    @app_commands.describe(user="Кого", reason="Причина", delete_days="Удалить сообщения (0-7 дней)")
    @app_commands.default_permissions(ban_members=True)
    async def mod_ban(
        self,
        interaction: discord.Interaction,
        user: discord.Member,
        reason: str = "Не указана",
        delete_days: app_commands.Range[int, 0, 7] = 1,
    ):
        cfg = load_config()
        if not is_admin(interaction.user, cfg) and interaction.user.top_role <= user.top_role:
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        try:
            await user.ban(reason=f"{interaction.user}: {reason}", delete_message_days=delete_days)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Нет прав.", ephemeral=True)
            return
        case_id = self._new_case(
            "ban", str(user.id), str(user), str(interaction.user.id), str(interaction.user), reason
        )
        embed = make_embed(
            title="🔨 Бан",
            description=f"{user.mention} забанен.",
            fields=[
                {"name": "Модератор", "value": interaction.user.mention, "inline": True},
                {"name": "Причина", "value": reason, "inline": False},
            ],
            color=0xED4245,
        )
        await self._send_modlog(interaction.guild, embed)
        await interaction.response.send_message(embed=embed)

    @mod_group.command(name="unban", description="Разбанить по ID")
    @app_commands.describe(user_id="ID пользователя")
    @app_commands.default_permissions(ban_members=True)
    async def mod_unban(self, interaction: discord.Interaction, user_id: str):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await interaction.guild.unban(user, reason=f"Разбан от {interaction.user}")
        except (discord.NotFound, discord.Forbidden, ValueError):
            await interaction.response.send_message("❌ Пользователь не найден.", ephemeral=True)
            return
        case_id = self._new_case(
            "unban", str(user.id), str(user), str(interaction.user.id), str(interaction.user), "Разбан"
        )
        embed = make_embed(
            title="🔓 Разбан",
            description=f"{user.mention} разбанен.",
            color=0x57F287,
        )
        await self._send_modlog(interaction.guild, embed)
        await interaction.response.send_message(embed=embed)

    @mod_group.command(name="clear", description="Очистить сообщения")
    @app_commands.describe(count="Сколько (1-100)", user="Только от этого пользователя")
    @app_commands.default_permissions(manage_messages=True)
    async def mod_clear(
        self,
        interaction: discord.Interaction,
        count: app_commands.Range[int, 1, 100],
        user: Optional[discord.Member] = None,
    ):
        await interaction.response.defer(ephemeral=True)
        deleted = 0
        if user:
            def check(m: discord.Message) -> bool:
                return m.author.id == user.id
            try:
                deleted = len(await interaction.channel.purge(limit=count * 3 if count < 50 else count * 2, check=check, bulk=True))
            except discord.HTTPException:
                pass
        else:
            try:
                deleted = len(await interaction.channel.purge(limit=count, bulk=True))
            except discord.HTTPException:
                pass
        await interaction.followup.send(f"🧹 Удалено сообщений: **{deleted}**", ephemeral=True)

    @mod_group.command(name="slowmode", description="Установить slowmode (0 = выключить)")
    @app_commands.describe(seconds="Секунды (0-21600)")
    @app_commands.default_permissions(manage_channels=True)
    async def mod_slowmode(self, interaction: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]):
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("❌ Только для текстовых каналов.", ephemeral=True)
            return
        await interaction.channel.edit(slowmode_delay=seconds)
        await interaction.response.send_message(f"✅ Slowmode: **{seconds}s**", ephemeral=True)

    @mod_group.command(name="modlog", description="Посмотреть историю модерации")
    @app_commands.describe(user="Фильтр по пользователю (необязательно)")
    @app_commands.default_permissions(manage_messages=True)
    async def mod_modlog(self, interaction: discord.Interaction, user: Optional[discord.Member] = None):
        cases = self.db.get("cases", [])
        if user:
            cases = [c for c in cases if c["user_id"] == str(user.id)]
        if not cases:
            await interaction.response.send_message("Лог пуст.", ephemeral=True)
            return
        embed = make_embed(
            title=f"📋 Лог модерации{' — '+str(user) if user else ''}",
            description=f"Всего: **{len(cases)}**",
        )
        for c in cases[-10:]:
            embed.add_field(
                name=f"#{c['id']} {c['action'].upper()} — {c['user_name']}",
                value=f"Модератор: <@{c['moderator_id']}>\nПричина: {c['reason']}\n{c['timestamp'][:19]}",
                inline=False,
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(ModerationCog(bot))
