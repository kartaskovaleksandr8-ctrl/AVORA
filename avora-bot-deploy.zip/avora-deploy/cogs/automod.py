"""
AutoMod cog.

Filters: anti-spam, anti-caps, anti-links, anti-invites.
Configured via config.json -> automod or slash commands.
"""
import re
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
import logging

from utils.helpers import load_config, save_config, make_embed, is_admin

log = logging.getLogger("avora_bot.automod")

DB_FILE = "automod_state.json"

# Match discord.gg/anything, discord.com/invite/anything, discordapp.com/invite/anything,
# discord.io/anything, discord.me/anything, discord.li/anything.
# Works with or without http:// prefix — catches "discord.gg/cwrA9fssz" too.
INVITE_RE = re.compile(
    r"(?:https?://)?(?:www\.)?"
    r"(?:discord\.(?:gg|io|me|li)"
    r"|discord(?:app)?\.com/invite)"
    r"/[A-Za-z0-9]+",
    re.IGNORECASE,
)
URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


class AutoModCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.recent_messages: dict[int, deque[datetime]] = defaultdict(lambda: deque(maxlen=20))

    def _is_ignored(self, member: discord.Member, cfg: dict, channel_id: int) -> bool:
        # Don't moderate bots or anyone with manage_messages
        if member.bot:
            return True
        if member.guild_permissions.manage_messages:
            return True
        automod = cfg.get("automod", {})
        if str(channel_id) in automod.get("ignored_channels", []):
            return True
        if any(str(r.id) in automod.get("ignored_roles", []) for r in member.roles):
            return True
        return False

    async def _check_message(self, message: discord.Message):
        """Common check used by both on_message and on_message_edit."""
        if not message.guild or message.author.bot:
            return
        cfg = load_config()
        automod = cfg.get("automod", {})
        if not automod.get("enabled"):
            return
        if self._is_ignored(message.author, cfg, message.channel.id):
            return

        content = message.content or ""
        reasons = []

        # Anti-spam: too many messages in short time
        if automod.get("anti_spam", True):
            now = datetime.now(timezone.utc)
            dq = self.recent_messages[message.author.id]
            dq.append(now)
            threshold = automod.get("spam_threshold", 5)
            window = timedelta(seconds=5)
            recent = [t for t in dq if now - t < window]
            if len(recent) > threshold:
                reasons.append("спам")

        # Anti-caps
        if automod.get("anti_caps", False) and len(content) > 5:
            letters = [c for c in content if c.isalpha()]
            if letters:
                caps_ratio = sum(1 for c in letters if c.isupper()) / len(letters) * 100
                if caps_ratio >= automod.get("caps_threshold", 70):
                    reasons.append("капс")

        # Anti-links
        if automod.get("anti_links", False) and URL_RE.search(content):
            reasons.append("ссылки")

        # Anti-invites
        if automod.get("anti_invites", True) and INVITE_RE.search(content):
            reasons.append("инвайт Discord")

        if reasons:
            log.info("AutoMod: deleting message from %s — reasons: %s", message.author, reasons)
            try:
                await message.delete()
            except (discord.HTTPException, discord.NotFound) as e:
                log.error("AutoMod: failed to delete message: %s", e)
            except discord.Forbidden:
                log.error("AutoMod: MISSING PERMISSIONS to delete messages. Bot needs 'Manage Messages' permission.")
                # Try to notify the channel
                try:
                    await message.channel.send(
                        "⚠️ AutoMod: у бота нет прав на удаление сообщений. "
                        "Выдайте боту разрешение 'Manage Messages' в настройках сервера.",
                        delete_after=10,
                    )
                except discord.HTTPException:
                    pass
            try:
                await message.channel.send(
                    f"⚠️ {message.author.mention}, нарушены правила: {', '.join(reasons)}",
                    delete_after=5,
                )
            except discord.HTTPException:
                pass

            # Log to modlog channel if configured
            log_channel_id = cfg.get("modlog_channel_id")
            if log_channel_id:
                log_ch = message.guild.get_channel(int(log_channel_id))
                if log_ch:
                    embed = make_embed(
                        title="🛡️ AutoMod",
                        description=f"**{message.author}** ({message.author.id}) нарушил правила",
                        fields=[
                            {"name": "Причина", "value": ", ".join(reasons), "inline": False},
                            {"name": "Канал", "value": message.channel.mention, "inline": True},
                            {"name": "Сообщение", "value": content[:1000] if content else "—", "inline": False},
                        ],
                        color=0xED4245,
                    )
                    try:
                        await log_ch.send(embed=embed)
                    except discord.HTTPException:
                        pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        await self._check_message(message)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        # Catch users editing a clean message to add a link/invite
        if before.content != after.content:
            await self._check_message(after)

    am_group = app_commands.Group(name="automod", description="Настройка AutoMod")

    @am_group.command(name="toggle", description="Включить/выключить AutoMod")
    @app_commands.default_permissions(manage_guild=True)
    async def am_toggle(self, interaction: discord.Interaction):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg.setdefault("automod", {})["enabled"] = not cfg.get("automod", {}).get("enabled", False)
        save_config(cfg)
        state = "включён" if cfg["automod"]["enabled"] else "выключен"
        await interaction.response.send_message(f"✅ AutoMod {state}.", ephemeral=True)

    @am_group.command(name="filter", description="Включить/выключить конкретный фильтр")
    @app_commands.describe(
        filter_name="anti_spam / anti_caps / anti_links / anti_invites",
        enabled_on="Включить",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def am_filter(self, interaction: discord.Interaction, filter_name: str, enabled_on: bool):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        valid = {"anti_spam", "anti_caps", "anti_links", "anti_invites"}
        if filter_name not in valid:
            await interaction.response.send_message(f"❌ Допустимые фильтры: {', '.join(valid)}", ephemeral=True)
            return
        cfg.setdefault("automod", {})[filter_name] = enabled_on
        save_config(cfg)
        await interaction.response.send_message(f"✅ {filter_name}: {'вкл' if enabled_on else 'выкл'}", ephemeral=True)

    @am_group.command(name="threshold", description="Установить порог спама (сообщений за 5 сек)")
    @app_commands.describe(threshold="Сколько сообщений за 5 сек считается спамом")
    @app_commands.default_permissions(manage_guild=True)
    async def am_threshold(self, interaction: discord.Interaction, threshold: app_commands.Range[int, 3, 50]):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg.setdefault("automod", {})["spam_threshold"] = threshold
        save_config(cfg)
        await interaction.response.send_message(f"✅ Порог спама: {threshold}", ephemeral=True)

    @am_group.command(name="ignore", description="Добавить канал/роль в исключения")
    @app_commands.describe(
        target="Канал или роль для игнорирования",
        remove="Убрать из исключений вместо добавления",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def am_ignore(
        self,
        interaction: discord.Interaction,
        target: app_commands.Union[discord.TextChannel, discord.Role],
        remove: bool = False,
    ):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        automod = cfg.setdefault("automod", {})
        if isinstance(target, discord.TextChannel):
            lst = automod.setdefault("ignored_channels", [])
        else:
            lst = automod.setdefault("ignored_roles", [])
        tid = str(target.id)
        if remove:
            if tid in lst:
                lst.remove(tid)
            msg = f"✅ Убрано из исключений: {target.mention}"
        else:
            if tid not in lst:
                lst.append(tid)
            msg = f"✅ Добавлено в исключения: {target.mention}"
        save_config(cfg)
        await interaction.response.send_message(msg, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(AutoModCog(bot))

