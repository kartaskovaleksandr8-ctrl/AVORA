"""
Giveaways cog.

Slash commands:
  /giveaway start <channel> <duration> <winners> <prize> [description]
  /giveaway end <message_id>
  /giveaway reroll <message_id>
  /giveaway list
"""
import discord
from discord import app_commands
from discord.ext import commands, tasks
from typing import Optional
from datetime import datetime, timedelta
import random

from utils.helpers import load_json, save_json, make_embed, is_admin, parse_duration, now_iso

DB_FILE = "giveaways.json"


class GiveawayButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="Участвовать",
            style=discord.ButtonStyle.success,
            custom_id="giveaway_join",
            emoji="🎉",
        )

    async def callback(self, interaction: discord.Interaction):
        await join_giveaway(interaction)


class GiveawayView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(GiveawayButton())


async def join_giveaway(interaction: discord.Interaction):
    db = load_json(DB_FILE, {"active": {}, "ended": []})
    active = db.get("active", {})
    g = active.get(str(interaction.message.id))
    if not g:
        await interaction.response.send_message("❌ Розыгрыш не найден или завершён.", ephemeral=True)
        return
    participants = g.setdefault("participants", [])
    uid = str(interaction.user.id)
    if uid in participants:
        participants.remove(uid)
        await interaction.response.send_message("❌ Вы вышли из розыгрыша.", ephemeral=True)
    else:
        participants.append(uid)
        await interaction.response.send_message("✅ Вы участвуете!", ephemeral=True)
    save_json(DB_FILE, db)


class GiveawaysCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.check_loop.start()

    def cog_unload(self):
        self.check_loop.cancel()

    @tasks.loop(seconds=15)
    async def check_loop(self):
        db = load_json(DB_FILE, {"active": {}, "ended": []})
        active = db.get("active", {})
        ended = db.get("ended", [])
        now = datetime.utcnow()
        changed = False
        for msg_id, g in list(active.items()):
            try:
                end_time = datetime.fromisoformat(g["ends_at"])
            except (ValueError, KeyError):
                continue
            if end_time <= now:
                await self._end_giveaway(msg_id, g)
                ended.append(g)
                del active[msg_id]
                changed = True
        if changed:
            db["active"] = active
            db["ended"] = ended
            save_json(DB_FILE, db)

    @check_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def _end_giveaway(self, msg_id: str, g: dict):
        channel = self.bot.get_channel(int(g["channel_id"]))
        if not channel:
            return
        try:
            msg = await channel.fetch_message(int(msg_id))
        except discord.HTTPException:
            return

        participants = g.get("participants", [])
        winners_count = g.get("winners", 1)
        if not participants:
            winner_mentions = "Нет участников"
        else:
            winners = random.sample(participants, min(winners_count, len(participants)))
            winner_mentions = ", ".join(f"<@{w}>" for w in winners)

        embed = make_embed(
            title=f"🎉 Розыгрыш завершён: {g['prize']}",
            description=f"Победител(ь/и): {winner_mentions}\nУчастников: **{len(participants)}**",
            color=0xFEE75C,
            
        )
        try:
            await msg.edit(embed=embed, view=None)
            await channel.send(
                content=winner_mentions if participants else "",
                embed=embed,
            )
        except discord.HTTPException:
            pass

    g_group = app_commands.Group(name="giveaway", description="Розыгрыши")

    @g_group.command(name="start", description="Запустить розыгрыш")
    @app_commands.describe(
        channel="Канал",
        duration="Длительность: 30s, 10m, 2h, 1d",
        winners="Количество победителей",
        prize="Приз",
        description="Описание (необязательно)",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def g_start(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        duration: str,
        winners: app_commands.Range[int, 1, 50],
        prize: str,
        description: Optional[str] = None,
    ):
        cfg = load_config()
        from utils.helpers import load_config as _lc
        cfg = _lc()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        seconds = parse_duration(duration)
        if not seconds:
            await interaction.response.send_message("❌ Некорректная длительность.", ephemeral=True)
            return
        ends_at = datetime.utcnow() + timedelta(seconds=seconds)
        embed = make_embed(
            title=f"🎉 Розыгрыш: {prize}",
            description=description or "Нажмите кнопку ниже, чтобы участвовать!",
            fields=[
                {"name": "Победителей", "value": f"**{winners}**", "inline": True},
                {"name": "Завершится", "value": f"<t:{int(ends_at.timestamp())}:R>", "inline": True},
                {"name": "Участников", "value": "**0**", "inline": True},
                {"name": "Организатор", "value": interaction.user.mention, "inline": True},
            ],
            color=0xFEE75C,
        )
        msg = await channel.send(embed=embed, view=GiveawayView())
        db = load_json(DB_FILE, {"active": {}, "ended": []})
        db.setdefault("active", {})[str(msg.id)] = {
            "message_id": str(msg.id),
            "channel_id": str(channel.id),
            "guild_id": str(interaction.guild.id),
            "prize": prize,
            "winners": winners,
            "description": description,
            "organizer_id": str(interaction.user.id),
            "participants": [],
            "ends_at": ends_at.isoformat(),
            "created_at": now_iso(),
        }
        save_json(DB_FILE, db)
        await interaction.response.send_message(f"✅ Розыгрыш запущен: {msg.jump_url}", ephemeral=True)

    @g_group.command(name="end", description="Завершить розыгрыш досрочно")
    @app_commands.describe(message_id="ID сообщения розыгрыша")
    @app_commands.default_permissions(manage_guild=True)
    async def g_end(self, interaction: discord.Interaction, message_id: str):
        from utils.helpers import load_config as _lc
        if not is_admin(interaction.user, _lc()):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"active": {}, "ended": []})
        active = db.get("active", {})
        g = active.get(message_id)
        if not g:
            await interaction.response.send_message("❌ Не найдено.", ephemeral=True)
            return
        await self._end_giveaway(message_id, g)
        del active[message_id]
        db["active"] = active
        db.setdefault("ended", []).append(g)
        save_json(DB_FILE, db)
        await interaction.response.send_message("✅ Завершён.", ephemeral=True)

    @g_group.command(name="reroll", description="Перевыбрать победителя завершённого розыгрыша")
    @app_commands.describe(message_id="ID сообщения")
    @app_commands.default_permissions(manage_guild=True)
    async def g_reroll(self, interaction: discord.Interaction, message_id: str):
        from utils.helpers import load_config as _lc
        if not is_admin(interaction.user, _lc()):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"active": {}, "ended": []})
        for g in db.get("ended", []):
            if g.get("message_id") == message_id:
                participants = g.get("participants", [])
                if not participants:
                    await interaction.response.send_message("❌ Нет участников.", ephemeral=True)
                    return
                winner = random.choice(participants)
                await interaction.response.send_message(f"🎉 Новый победитель: <@{winner}>")
                return
        await interaction.response.send_message("❌ Не найдено.", ephemeral=True)

    @g_group.command(name="list", description="Список активных розыгрышей")
    async def g_list(self, interaction: discord.Interaction):
        db = load_json(DB_FILE, {"active": {}, "ended": []})
        active = db.get("active", {})
        if not active:
            await interaction.response.send_message("Нет активных розыгрышей.", ephemeral=True)
            return
        embed = make_embed(title="🎉 Активные розыгрыши")
        for mid, g in list(active.items())[:25]:
            embed.add_field(
                name=g["prize"],
                value=f"Канал: <#{g['channel_id']}>\nПобедителей: {g['winners']}\nЗавершится: <t:{int(datetime.fromisoformat(g['ends_at']).timestamp())}:R>",
                inline=False,
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(GiveawaysCog(bot))
    bot.add_view(GiveawayView())
