"""
Tickets cog — AVORA BOT ticket system with app sync.

Features:
- /ticket panel create — creates a panel message with "Open Ticket" button
- User clicks button → creates private text channel with user + admin role
- All conversation synced to JSON archive (database/tickets.json)
- /ticket close — closes ticket, deletes channel, saves transcript
- Closing from app also works via API endpoint
- Archive survives bot restarts — closed tickets stay until manually deleted
- Works even if bot is offline (app reads archive JSON directly)
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
from typing import Optional, Any, Dict, List

from utils.helpers import (
    load_config, save_config, load_json, save_json, make_embed, is_admin,
    now_iso, APP_DIR, DB_DIR
)

import asyncio
import logging
import os

log = logging.getLogger("avora_bot.tickets")

DB_FILE = "tickets.json"
ARCHIVE_DIR = DB_DIR / "ticket_archive"


def _load_tickets_db() -> Dict[str, Any]:
    """Load the tickets database. Returns dict with 'active' and 'closed' lists."""
    data = load_json(DB_FILE, default={"active": {}, "closed": {}})
    if "active" not in data:
        data["active"] = {}
    if "closed" not in data:
        data["closed"] = {}
    return data


def _save_tickets_db(data: Dict[str, Any]) -> None:
    """Save the tickets database."""
    save_json(DB_FILE, data)


def _ensure_archive_dir() -> None:
    """Make sure archive directory exists for transcripts."""
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)


class TicketPanelButton(discord.ui.Button):
    """The 'Open Ticket' button shown on the panel message."""
    def __init__(self):
        super().__init__(
            label="🎫 Создать тикет",
            style=discord.ButtonStyle.primary,
            custom_id="avora_ticket_open",
            emoji="🎫",
        )

    async def callback(self, interaction: discord.Interaction):
        cog: "Tickets" = interaction.client.get_cog("Tickets")
        if cog is None:
            await interaction.response.send_message(
                "❌ Модуль тикетов не загружен.", ephemeral=True
            )
            return
        await cog.open_ticket_for_user(interaction)


class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketPanelButton())


class TicketCloseButton(discord.ui.Button):
    """Close button shown in ticket channels."""
    def __init__(self):
        super().__init__(
            label="Закрыть тикет",
            style=discord.ButtonStyle.danger,
            custom_id="avora_ticket_close",
            emoji="🔒",
        )

    async def callback(self, interaction: discord.Interaction):
        cog: "Tickets" = interaction.client.get_cog("Tickets")
        if cog is None:
            await interaction.response.send_message(
                "❌ Модуль тикетов не загружен.", ephemeral=True
            )
            return
        await cog.close_ticket(interaction, interaction.channel)


class TicketCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketCloseButton())


class Tickets(commands.Cog):
    """AVORA BOT ticket system with app synchronization."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        _ensure_archive_dir()
        # Persist views so buttons keep working after bot restart
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketCloseView())

    # ===== Commands =====

    group = app_commands.Group(name="ticket", description="Управление тикетами")

    @group.command(name="panel", description="Создать панель для тикетов в текущем канале")
    @app_commands.describe(title="Заголовок панели", description="Описание панели")
    async def panel_create(
        self,
        interaction: discord.Interaction,
        title: str = "Поддержка",
        description: str = "Нажмите кнопку ниже, чтобы создать тикет с администратором.",
    ):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message(
                "❌ Только администратор может создать панель тикетов.",
                ephemeral=True,
            )
            return

        embed = make_embed(
            title=title,
            description=description,
            color=int("5865F2", 16),
            
        )
        view = TicketPanelView()
        await interaction.channel.send(embed=embed, view=view)
        await interaction.response.send_message(
            "✅ Панель тикетов создана!", ephemeral=True
        )

    @group.command(name="close", description="Закрыть текущий тикет")
    async def close_cmd(self, interaction: discord.Interaction):
        channel = interaction.channel
        result = await self._close_ticket_internal(channel, closed_by=interaction.user)
        if result["ok"]:
            await interaction.response.send_message(
                f"🔒 Тикет закрыт пользователем {interaction.user.mention}.",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                f"❌ {result['error']}", ephemeral=True
            )

    @group.command(name="add", description="Добавить пользователя в текущий тикет")
    @app_commands.describe(user="Пользователь, которого нужно добавить")
    async def add_user(self, interaction: discord.Interaction, user: discord.Member):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message(
                "❌ Только администратор может добавлять пользователей.",
                ephemeral=True,
            )
            return
        db = _load_tickets_db()
        ticket = db["active"].get(str(interaction.channel.id))
        if not ticket:
            await interaction.response.send_message(
                "❌ Это не тикет-канал.", ephemeral=True
            )
            return
        await interaction.channel.set_permissions(
            user, view_channel=True, send_messages=True, read_message_history=True
        )
        await interaction.response.send_message(
            f"✅ {user.mention} добавлен в тикет.", ephemeral=False
        )

    # ===== Event handlers =====

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Sync every message in ticket channels to the JSON archive."""
        if message.author.bot:
            return
        if not message.guild:
            return
        db = _load_tickets_db()
        channel_id = str(message.channel.id)
        if channel_id not in db["active"]:
            return

        ticket = db["active"][channel_id]
        # Append message to transcript
        msg_entry = {
            "id": str(message.id),
            "author_id": str(message.author.id),
            "author_name": message.author.display_name,
            "author_is_admin": is_admin(message.author, load_config()),
            "content": message.content,
            "timestamp": message.created_at.isoformat() if message.created_at else now_iso(),
            "attachments": [a.url for a in message.attachments] if message.attachments else [],
        }
        ticket["messages"].append(msg_entry)
        ticket["last_message_at"] = msg_entry["timestamp"]
        _save_tickets_db(db)

    # ===== Ticket operations =====

    async def open_ticket_for_user(self, interaction: discord.Interaction):
        """Create a private ticket channel for the user who clicked the button."""
        cfg = load_config()
        guild = interaction.guild
        user = interaction.user

        # Check if user already has an open ticket
        db = _load_tickets_db()
        for chan_id, t in db["active"].items():
            if t.get("user_id") == str(user.id) and t.get("guild_id") == str(guild.id):
                existing_channel = guild.get_channel(int(chan_id))
                if existing_channel:
                    await interaction.response.send_message(
                        f"❌ У вас уже есть открытый тикет: {existing_channel.mention}",
                        ephemeral=True,
                    )
                    return

        # Create channel — try to put it in a "Tickets" category
        category = None
        cat_id = cfg.get("tickets_category_id")
        if cat_id:
            try:
                category = guild.get_channel(int(cat_id))
            except (ValueError, TypeError):
                pass
        if category is None:
            # Try to find or create a "Tickets" category
            category = discord.utils.get(guild.categories, name="Tickets")
            if category is None:
                try:
                    category = await guild.create_category("Tickets")
                except discord.Forbidden:
                    category = None

        # Channel name: ticket-<username>
        overwrites = self._build_channel_overwrites(guild, user, cfg)
        try:
            channel = await guild.create_text_channel(
                name=f"ticket-{user.name.lower()[:20]}",
                category=category,
                overwrites=overwrites,
                topic=f"Тикет пользователя {user} ({user.id}). Создан: {now_iso()}",
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ У бота нет прав на создание каналов.", ephemeral=True
            )
            return
        except discord.HTTPException as e:
            await interaction.response.send_message(
                f"❌ Ошибка создания канала: {e}", ephemeral=True
            )
            return

        # Send greeting message with close button
        embed = make_embed(
            title="🎫 Тикет открыт",
            description=(
                f"Привет, {user.mention}! Администратор скоро ответит тебе.\n\n"
                f"Опиши свою проблему максимально подробно. Когда вопрос будет решён — "
                f"нажми кнопку «Закрыть тикет» ниже."
            ),
            color=int("22c55e", 16),
            
        )
        view = TicketCloseView()
        await channel.send(embed=embed, view=view)

        # Ping admins
        admin_role_id = cfg.get("admin_role_id")
        if admin_role_id:
            try:
                admin_role = guild.get_role(int(admin_role_id))
                if admin_role:
                    await channel.send(
                        f"{admin_role.mention} — новый тикет от {user.mention}.",
                        allowed_mentions=discord.AllowedMentions(roles=True, users=True),
                    )
            except (ValueError, TypeError):
                pass

        # Save to DB
        ticket = {
            "ticket_id": str(channel.id),
            "channel_id": str(channel.id),
            "guild_id": str(guild.id),
            "user_id": str(user.id),
            "user_name": user.display_name,
            "user_display_avatar": str(user.display_avatar.url) if user.display_avatar else "",
            "created_at": now_iso(),
            "last_message_at": now_iso(),
            "status": "active",
            "subject": "(без темы)",
            "messages": [
                {
                    "id": "system",
                    "author_id": "system",
                    "author_name": "AVORA BOT",
                    "author_is_admin": True,
                    "content": f"Тикет создан пользователем {user.display_name}.",
                    "timestamp": now_iso(),
                    "attachments": [],
                    "system": True,
                }
            ],
        }
        db["active"][str(channel.id)] = ticket
        _save_tickets_db(db)

        await interaction.response.send_message(
            f"✅ Тикет создан: {channel.mention}", ephemeral=True
        )

    def _build_channel_overwrites(
        self, guild: discord.Guild, user: discord.Member, cfg: Dict[str, Any]
    ) -> Dict[discord.Member, discord.PermissionOverwrite]:
        """Permission overwrites: user + admin role can see, everyone else can't."""
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            guild.me: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                manage_channels=True,
                read_message_history=True,
            ),
            user: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
            ),
        }
        # Add admin role
        admin_role_id = cfg.get("admin_role_id")
        if admin_role_id:
            try:
                admin_role = guild.get_role(int(admin_role_id))
                if admin_role:
                    overwrites[admin_role] = discord.PermissionOverwrite(
                        view_channel=True,
                        send_messages=True,
                        read_message_history=True,
                        manage_channels=True,
                    )
            except (ValueError, TypeError):
                pass
        # Owner
        owner_id = cfg.get("owner_discord_id")
        if owner_id:
            try:
                owner = guild.get_member(int(owner_id))
                if owner:
                    overwrites[owner] = discord.PermissionOverwrite(
                        view_channel=True,
                        send_messages=True,
                        read_message_history=True,
                        manage_channels=True,
                    )
            except (ValueError, TypeError):
                pass
        return overwrites

    async def close_ticket(
        self, interaction: discord.Interaction, channel: discord.TextChannel
    ):
        """Close ticket from Discord button click."""
        cfg = load_config()
        # Either the ticket owner or an admin can close
        db = _load_tickets_db()
        ticket = db["active"].get(str(channel.id))
        if not ticket:
            await interaction.response.send_message(
                "❌ Это не тикет-канал.", ephemeral=True
            )
            return
        is_owner_of_ticket = str(interaction.user.id) == ticket.get("user_id")
        is_admin_user = is_admin(interaction.user, cfg)
        if not (is_owner_of_ticket or is_admin_user):
            await interaction.response.send_message(
                "❌ Только автор тикета или администратор может его закрыть.",
                ephemeral=True,
            )
            return
        result = await self._close_ticket_internal(channel, closed_by=interaction.user)
        if result["ok"]:
            try:
                await interaction.response.send_message(
                    f"🔒 Тикет закрыт {interaction.user.mention}. Канал будет удалён через 5 секунд...",
                    ephemeral=False,
                )
            except discord.InteractionResponded:
                pass
        else:
            try:
                await interaction.response.send_message(
                    f"❌ {result['error']}", ephemeral=True
                )
            except discord.InteractionResponded:
                pass

    async def _close_ticket_internal(
        self, channel: discord.TextChannel, closed_by: Any
    ) -> Dict[str, Any]:
        """Internal close logic. Returns dict with 'ok' and optionally 'error'."""
        db = _load_tickets_db()
        channel_id = str(channel.id)
        ticket = db["active"].get(channel_id)
        if not ticket:
            return {"ok": False, "error": "Это не активный тикет."}

        # Save final transcript (in case any messages weren't synced)
        try:
            async for msg in channel.history(limit=None, oldest_first=True):
                if msg.author.bot and msg.author != self.bot.user:
                    continue
                msg_id = str(msg.id)
                if any(m.get("id") == msg_id for m in ticket["messages"]):
                    continue
                ticket["messages"].append({
                    "id": msg_id,
                    "author_id": str(msg.author.id),
                    "author_name": msg.author.display_name,
                    "author_is_admin": is_admin(msg.author, load_config()),
                    "content": msg.content,
                    "timestamp": msg.created_at.isoformat() if msg.created_at else now_iso(),
                    "attachments": [a.url for a in msg.attachments],
                })
        except discord.HTTPException as e:
            log.warning("Failed to fetch channel history for transcript: %s", e)

        # Move to closed
        ticket["status"] = "closed"
        ticket["closed_at"] = now_iso()
        ticket["closed_by_id"] = str(getattr(closed_by, "id", "unknown"))
        ticket["closed_by_name"] = getattr(closed_by, "display_name", "unknown")

        # Save full transcript as separate file (for easy download later)
        transcript_path = ARCHIVE_DIR / f"{channel_id}.json"
        try:
            import json
            with open(transcript_path, "w", encoding="utf-8") as f:
                json.dump(ticket, f, indent=2, ensure_ascii=False, default=str)
        except Exception as e:
            log.error("Failed to save transcript file: %s", e)

        # Move ticket from active to closed
        db["closed"][channel_id] = ticket
        del db["active"][channel_id]
        _save_tickets_db(db)

        # Delete the Discord channel
        try:
            await channel.delete(reason=f"Тикет закрыт пользователем {closed_by}")
        except discord.Forbidden:
            log.warning("No permission to delete ticket channel %s", channel_id)
        except discord.HTTPException as e:
            log.warning("Failed to delete channel %s: %s", channel_id, e)

        return {"ok": True, "ticket_id": channel_id}

    # ===== Public API for FastAPI bridge =====

    def get_active_tickets(self) -> List[Dict[str, Any]]:
        """Return list of active tickets, sorted by last_message_at desc."""
        db = _load_tickets_db()
        items = list(db["active"].values())
        items.sort(key=lambda t: t.get("last_message_at", ""), reverse=True)
        return items

    def get_closed_tickets(self) -> List[Dict[str, Any]]:
        """Return list of closed/archived tickets, sorted by closed_at desc."""
        db = _load_tickets_db()
        items = list(db["closed"].values())
        items.sort(key=lambda t: t.get("closed_at", ""), reverse=True)
        return items

    def get_ticket(self, ticket_id: str) -> Optional[Dict[str, Any]]:
        """Get a single ticket by ID (channel ID). Searches both active and closed."""
        db = _load_tickets_db()
        if ticket_id in db["active"]:
            return db["active"][ticket_id]
        if ticket_id in db["closed"]:
            return db["closed"][ticket_id]
        return None

    async def send_reply_from_app(
        self, ticket_id: str, message: str, author_name: str = "Администратор"
    ) -> Dict[str, Any]:
        """Send a message to the ticket channel from the app.
        Used by admins when replying via the desktop app."""
        db = _load_tickets_db()
        ticket = db["active"].get(ticket_id)
        if not ticket:
            return {"ok": False, "error": "Тикет не найден или уже закрыт."}

        channel_id = int(ticket["channel_id"])
        guild_id = int(ticket["guild_id"])
        guild = self.bot.get_guild(guild_id)
        if not guild:
            return {"ok": False, "error": "Сервер бота недоступен."}
        channel = guild.get_channel(channel_id)
        if not channel:
            # Channel was deleted externally — auto-close the ticket
            return await self._close_orphan_ticket(ticket_id, reason="Канал удалён")

        try:
            sent = await channel.send(
                f"💬 **{author_name}**: {message}",
                allowed_mentions=discord.AllowedMentions.none(),
            )
        except discord.Forbidden:
            return {"ok": False, "error": "Нет прав на отправку сообщений в канал."}
        except discord.HTTPException as e:
            return {"ok": False, "error": f"Discord error: {e}"}

        # Save the reply in the transcript
        msg_entry = {
            "id": str(sent.id),
            "author_id": "app_admin",
            "author_name": author_name,
            "author_is_admin": True,
            "content": message,
            "timestamp": sent.created_at.isoformat() if sent.created_at else now_iso(),
            "attachments": [],
            "from_app": True,
        }
        ticket["messages"].append(msg_entry)
        ticket["last_message_at"] = msg_entry["timestamp"]
        _save_tickets_db(db)

        return {"ok": True, "message_id": str(sent.id)}

    async def close_ticket_from_app(
        self, ticket_id: str, closed_by_name: str = "Администратор"
    ) -> Dict[str, Any]:
        """Close a ticket from the app. Returns dict with 'ok'."""
        db = _load_tickets_db()
        ticket = db["active"].get(ticket_id)
        if not ticket:
            return {"ok": False, "error": "Тикет не найден или уже закрыт."}

        guild_id = int(ticket["guild_id"])
        channel_id = int(ticket["channel_id"])
        guild = self.bot.get_guild(guild_id)
        if not guild:
            return await self._close_orphan_ticket(ticket_id, reason="Сервер недоступен")
        channel = guild.get_channel(channel_id)
        if not channel:
            return await self._close_orphan_ticket(ticket_id, reason="Канал удалён")

        # Fake "closed_by" object
        class _Closer:
            def __init__(self, name, id):
                self.display_name = name
                self.id = id
        closer = _Closer(closed_by_name, 0)

        return await self._close_ticket_internal(channel, closed_by=closer)

    async def _close_orphan_ticket(self, ticket_id: str, reason: str = "") -> Dict[str, Any]:
        """Close a ticket whose Discord channel is gone — just archive it."""
        db = _load_tickets_db()
        ticket = db["active"].get(ticket_id)
        if not ticket:
            return {"ok": False, "error": "Тикет не найден."}
        ticket["status"] = "closed"
        ticket["closed_at"] = now_iso()
        ticket["closed_by_name"] = "Система"
        ticket["orphaned"] = True
        ticket["orphan_reason"] = reason
        db["closed"][ticket_id] = ticket
        del db["active"][ticket_id]
        _save_tickets_db(db)
        # Save transcript file too
        import json
        transcript_path = ARCHIVE_DIR / f"{ticket_id}.json"
        try:
            with open(transcript_path, "w", encoding="utf-8") as f:
                json.dump(ticket, f, indent=2, ensure_ascii=False, default=str)
        except Exception:
            pass
        return {"ok": True, "orphaned": True}

    async def delete_closed_ticket(self, ticket_id: str) -> Dict[str, Any]:
        """Permanently delete a closed ticket from the archive."""
        db = _load_tickets_db()
        if ticket_id not in db["closed"]:
            return {"ok": False, "error": "Закрытый тикет не найден."}
        del db["closed"][ticket_id]
        _save_tickets_db(db)
        # Also delete the transcript file
        transcript_path = ARCHIVE_DIR / f"{ticket_id}.json"
        try:
            if transcript_path.exists():
                transcript_path.unlink()
        except Exception:
            pass
        return {"ok": True}

    async def create_panel_in_channel(
        self, channel_id: int, title: str, description: str
    ) -> Dict[str, Any]:
        """Create a ticket panel message in a specific channel (called from app)."""
        cfg = load_config()
        # Use bot.get_channel (searches ALL guilds, more reliable than guild.get_channel
        # which only searches cache). Fallback to fetch_channel if not in cache.
        channel = self.bot.get_channel(channel_id)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(channel_id)
            except (discord.NotFound, discord.Forbidden):
                pass
        if channel is None:
            return {"ok": False, "error": f"Канал {channel_id} не найден. Убедитесь что бот видит этот канал."}
        try:
            embed = make_embed(
                title=title or "Поддержка",
                description=description or "Нажмите кнопку ниже, чтобы создать тикет с администратором.",
                color=int("5865F2", 16),
            )
            view = TicketPanelView()
            msg = await channel.send(embed=embed, view=view)
            return {"ok": True, "message_id": str(msg.id), "channel_id": str(channel_id)}
        except discord.Forbidden:
            return {"ok": False, "error": "У бота нет прав на отправку сообщений в этот канал."}
        except discord.HTTPException as e:
            return {"ok": False, "error": f"Discord error: {e}"}


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Tickets(bot))
    log.info("Tickets cog loaded")
