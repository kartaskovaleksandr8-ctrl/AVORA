"""
Reaction Roles cog.

Slash command:
  /reactionrole create <channel> <message_id> <role> <emoji> [title] [description]
  /reactionrole remove <message_id> <emoji>
  /reactionrole list

Stores mapping message_id -> {emoji: role_id} in reaction_roles.json.
"""
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional
import logging

from utils.helpers import load_json, save_json, make_embed, is_admin, load_config

log = logging.getLogger("avora_bot.reaction_roles")

DB_FILE = "reaction_roles.json"


class ReactionRolesCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_db(self) -> dict:
        """Reload DB from disk every time — so changes via API are visible."""
        return load_json(DB_FILE, {"messages": {}})

    def _save_db(self, db: dict):
        save_json(DB_FILE, db)

    def _find_emoji_key(self, payload_emoji, reactions: dict) -> Optional[str]:
        """Match the reaction emoji against stored keys. Discord represents
        emojis differently in different contexts — this handles all variants."""
        # Standard unicode emoji: str(payload.emoji) = "👍"
        key = str(payload_emoji)
        if key in reactions:
            return key
        # Custom emoji: str = "<:name:id>" or "<a:name:id>"
        if payload_emoji.id:
            for fmt in [
                f"<:{payload_emoji.name}:{payload_emoji.id}>",
                f"<a:{payload_emoji.name}:{payload_emoji.id}>",
                f":{payload_emoji.name}:",
                payload_emoji.name,
            ]:
                if fmt in reactions:
                    return fmt
        # Try just the name
        if payload_emoji.name in reactions:
            return payload_emoji.name
        return None

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if payload.guild_id is None:
            return
        db = self._get_db()
        msg_data = db.get("messages", {}).get(str(payload.message_id))
        if not msg_data:
            return

        emoji_key = self._find_emoji_key(payload.emoji, msg_data.get("reactions", {}))
        if not emoji_key:
            return

        role_id_str = msg_data["reactions"][emoji_key]
        try:
            role_id = int(role_id_str)
        except (ValueError, TypeError):
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        role = guild.get_role(role_id)
        if not role:
            log.warning("Role %s not found in guild %s", role_id, guild.id)
            return

        # payload.member is only populated if members intent is enabled.
        # If it's None, fetch the member manually.
        member = payload.member
        if member is None:
            try:
                member = await guild.fetch_member(payload.user_id)
            except (discord.NotFound, discord.Forbidden):
                return

        try:
            await member.add_roles(role, reason="Reaction Role")
            log.info("Added role %s to %s", role.name, member)
        except discord.Forbidden:
            log.error("Missing permissions to add role %s. Bot needs Manage Roles + role hierarchy.", role.name)
            # Try to DM the user about the error
            try:
                await member.send(f"❌ Не удалось выдать роль {role.name} — у бота нет прав. Попросите администратора проверить: 1) у бота есть разрешение 'Manage Roles', 2) роль бота выше роли {role.name}.")
            except discord.Forbidden:
                pass
        except discord.HTTPException as e:
            log.error("Failed to add role: %s", e)

        # Remove the user's reaction if configured
        if msg_data.get("remove_reaction", True):
            channel = guild.get_channel(payload.channel_id) or await self.bot.fetch_channel(payload.channel_id)
            if channel:
                try:
                    msg = await channel.fetch_message(payload.message_id)
                    await msg.remove_reaction(payload.emoji, member)
                except discord.HTTPException:
                    pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        if payload.guild_id is None:
            return
        db = self._get_db()
        msg_data = db.get("messages", {}).get(str(payload.message_id))
        if not msg_data:
            return

        emoji_key = self._find_emoji_key(payload.emoji, msg_data.get("reactions", {}))
        if not emoji_key:
            return

        try:
            role_id = int(msg_data["reactions"][emoji_key])
        except (ValueError, TypeError):
            return

        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        member = guild.get_member(payload.user_id)
        if not member:
            try:
                member = await guild.fetch_member(payload.user_id)
            except (discord.NotFound, discord.Forbidden):
                return
        role = guild.get_role(role_id)
        if not role:
            return
        try:
            await member.remove_roles(role, reason="Reaction Role remove")
        except discord.Forbidden:
            log.error("Missing permissions to remove role %s", role.name)
        except discord.HTTPException:
            pass

    rr_group = app_commands.Group(name="reactionrole", description="Reaction Roles")

    @rr_group.command(name="create", description="Создать Reaction Role на существующем сообщении")
    @app_commands.describe(
        channel="Канал с сообщением",
        message_id="ID сообщения",
        role="Роль, которая выдаётся",
        emoji="Эмодзи (стандартный или :name:)",
        title="Заголовок (если нужно создать новое сообщение)",
        description="Описание (если нужно создать новое сообщение)",
    )
    @app_commands.default_permissions(manage_roles=True)
    async def rr_create(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        message_id: str,
        role: discord.Role,
        emoji: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
    ):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return

        # Try to fetch existing message
        try:
            msg = await channel.fetch_message(int(message_id))
        except (discord.NotFound, discord.Forbidden, ValueError):
            # Create new message if title given
            if title:
                embed = make_embed(
                    title=title,
                    description=description or "Нажмите на реакцию, чтобы получить роль.",
                )
                msg = await channel.send(embed=embed)
                message_id = str(msg.id)
            else:
                await interaction.response.send_message(
                    "❌ Сообщение не найдено. Укажите `title`, чтобы создать новое.",
                    ephemeral=True,
                )
                return

        # Add reaction
        try:
            await msg.add_reaction(emoji)
        except discord.HTTPException as e:
            await interaction.response.send_message(f"❌ Не удалось добавить эмодзи: {e}", ephemeral=True)
            return

        messages = db = self._get_db(); db.setdefault("messages", {})
        msg_entry = messages.setdefault(str(message_id), {
            "channel_id": str(channel.id),
            "guild_id": str(interaction.guild.id),
            "reactions": {},
            "remove_reaction": True,
        })
        msg_entry["reactions"][emoji] = str(role.id)
        self._save_db(db)

        await interaction.response.send_message(
            f"✅ Reaction Role создан!\nСообщение: {msg.jump_url}\nРоль: {role.mention}\nЭмодзи: {emoji}",
            ephemeral=True,
        )

    @rr_group.command(name="remove", description="Убрать Reaction Role с сообщения")
    @app_commands.describe(message_id="ID сообщения", emoji="Эмодзи")
    @app_commands.default_permissions(manage_roles=True)
    async def rr_remove(self, interaction: discord.Interaction, message_id: str, emoji: str):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        messages = db = self._get_db(); db.get("messages", {})
        msg_data = messages.get(message_id)
        if not msg_data or emoji not in msg_data.get("reactions", {}):
            await interaction.response.send_message("❌ Запись не найдена.", ephemeral=True)
            return
        del msg_data["reactions"][emoji]
        if not msg_data["reactions"]:
            del messages[message_id]
        self._save_db(db)
        await interaction.response.send_message("✅ Удалено.", ephemeral=True)

    @rr_group.command(name="list", description="Список всех Reaction Role сообщений")
    async def rr_list(self, interaction: discord.Interaction):
        messages = db = self._get_db(); db.get("messages", {})
        if not messages:
            await interaction.response.send_message("Пока нет Reaction Role сообщений.", ephemeral=True)
            return
        embed = make_embed(title="🎯 Reaction Roles")
        for mid, data in list(messages.items())[:25]:
            reactions_str = "\n".join(
                f"{e} → <@&{rid}>" for e, rid in data.get("reactions", {}).items()
            ) or "—"
            embed.add_field(
                name=f"Сообщение {mid}",
                value=f"Канал: <#{data['channel_id']}>\n{reactions_str}",
                inline=False,
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(ReactionRolesCog(bot))
