"""
Utility cog — полезные команды.

Commands:
  /userinfo [user]
  /serverinfo
  /avatar [user]
  /ping
  /poll <question> <option1> <option2> [option3] ... [option5]
  /remind <time> <text>
  /embed <channel> <json|title> [description]
  /roleinfo <role>
  /membercount
  /servericon
  /role all|add|remove
  /random <min> <max>
  /8ball <question>
  /choose <option1> <option2> ...
  /urban <term>
"""
import discord
from discord import app_commands
from discord.ext import commands, tasks
from typing import Optional
import random
import asyncio
from datetime import datetime, timedelta

from utils.helpers import make_embed, is_admin, parse_duration, load_json, save_json, now_iso

DB_FILE = "reminders.json"


class UtilsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.reminder_loop.start()

    def cog_unload(self):
        self.reminder_loop.cancel()

    @tasks.loop(seconds=10)
    async def reminder_loop(self):
        db = load_json(DB_FILE, {"reminders": []})
        now = datetime.utcnow()
        changed = False
        remaining = []
        for r in db.get("reminders", []):
            try:
                due = datetime.fromisoformat(r["due"])
            except (ValueError, KeyError):
                continue
            if due <= now:
                await self._fire_reminder(r)
                changed = True
            else:
                remaining.append(r)
        if changed:
            db["reminders"] = remaining
            save_json(DB_FILE, db)

    @reminder_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def _fire_reminder(self, r: dict):
        channel = self.bot.get_channel(int(r["channel_id"]))
        if not channel:
            return
        try:
            await channel.send(
                content=f"<@{r['user_id']}>",
                embed=make_embed(
                    title="⏰ Напоминание",
                    description=r["text"],
                    color=0xFEE75C,
                ),
            )
        except discord.HTTPException:
            pass

    @app_commands.command(name="userinfo", description="Информация о пользователе")
    @app_commands.describe(user="Кто (по умолчанию вы)")
    async def userinfo(self, interaction: discord.Interaction, user: Optional[discord.Member] = None):
        user = user or interaction.user
        roles = [r.mention for r in user.roles if r != interaction.guild.default_role][:15]
        embed = make_embed(
            title=f"👤 {user.display_name}",
            color=user.color if user.color.value else None,
            fields=[
                {"name": "ID", "value": f"`{user.id}`", "inline": True},
                {"name": "Аккаунт создан", "value": f"<t:{int(user.created_at.timestamp())}:D>", "inline": True},
                {"name": "Зашёл на сервер", "value": f"<t:{int(user.joined_at.timestamp())}:D>" if user.joined_at else "—", "inline": True},
                {"name": "Роли", "value": ", ".join(roles) if roles else "—", "inline": False},
                {"name": "Высшая роль", "value": user.top_role.mention if user.top_role else "—", "inline": True},
                {"name": "Бот?", "value": "Да" if user.bot else "Нет", "inline": True},
            ],
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="serverinfo", description="Информация о сервере")
    async def serverinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        embed = make_embed(
            title=f"🏠 {g.name}",
            fields=[
                {"name": "ID", "value": f"`{g.id}`", "inline": True},
                {"name": "Создан", "value": f"<t:{int(g.created_at.timestamp())}:D>", "inline": True},
                {"name": "Владелец", "value": g.owner.mention if g.owner else "—", "inline": True},
                {"name": "Участников", "value": f"**{g.member_count}**", "inline": True},
                {"name": "Каналов", "value": f"**{len(g.channels)}**", "inline": True},
                {"name": "Ролей", "value": f"**{len(g.roles)}**", "inline": True},
                {"name": "Эмодзи", "value": f"**{len(g.emojis)}**", "inline": True},
                {"name": "Уровень буста", "value": f"**{g.premium_tier}** ({g.premium_subscription_count} бустов)", "inline": True},
            ],
        )
        if g.icon:
            embed.set_thumbnail(url=g.icon.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="avatar", description="Аватарка пользователя")
    @app_commands.describe(user="Кто")
    async def avatar(self, interaction: discord.Interaction, user: Optional[discord.User] = None):
        user = user or interaction.user
        embed = make_embed(title=f"🖼️ Аватар — {user}")
        embed.set_image(url=user.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="servericon", description="Иконка сервера")
    async def servericon(self, interaction: discord.Interaction):
        g = interaction.guild
        if not g.icon:
            await interaction.response.send_message("У сервера нет иконки.", ephemeral=True)
            return
        embed = make_embed(title=f"🖼️ Иконка — {g.name}")
        embed.set_image(url=g.icon.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ping", description="Пинг бота")
    async def ping(self, interaction: discord.Interaction):
        latency_ms = round(self.bot.latency * 1000)
        embed = make_embed(
            title="🏓 Пинг",
            description=f"**WebSocket:** {latency_ms} ms",
            color=0x57F287 if latency_ms < 200 else (0xFEE75C if latency_ms < 500 else 0xED4245),
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="poll", description="Создать опрос")
    @app_commands.describe(
        question="Вопрос",
        option1="Вариант 1",
        option2="Вариант 2",
        option3="Вариант 3 (необязательно)",
        option4="Вариант 4 (необязательно)",
        option5="Вариант 5 (необязательно)",
    )
    async def poll(
        self,
        interaction: discord.Interaction,
        question: str,
        option1: str,
        option2: str,
        option3: Optional[str] = None,
        option4: Optional[str] = None,
        option5: Optional[str] = None,
    ):
        options = [(option1, "1️⃣"), (option2, "2️⃣")]
        if option3:
            options.append((option3, "3️⃣"))
        if option4:
            options.append((option4, "4️⃣"))
        if option5:
            options.append((option5, "5️⃣"))

        embed = make_embed(
            title="📊 Опрос",
            description=f"**{question}**\n\n" + "\n".join(f"{e} {o}" for o, e in options),
        )
        
        await interaction.response.send_message(embed=embed)
        msg = await interaction.original_response()
        for _, e in options:
            try:
                await msg.add_reaction(e)
            except discord.HTTPException:
                pass

    @app_commands.command(name="remind", description="Напоминание")
    @app_commands.describe(time="Через сколько: 30s, 10m, 2h, 1d", text="Текст напоминания")
    async def remind(self, interaction: discord.Interaction, time: str, text: str):
        seconds = parse_duration(time)
        if not seconds:
            await interaction.response.send_message("❌ Некорректное время.", ephemeral=True)
            return
        due = datetime.utcnow() + timedelta(seconds=seconds)
        db = load_json(DB_FILE, {"reminders": []})
        db.setdefault("reminders", []).append({
            "user_id": str(interaction.user.id),
            "channel_id": str(interaction.channel.id),
            "text": text,
            "due": due.isoformat(),
            "created_at": now_iso(),
        })
        save_json(DB_FILE, db)
        await interaction.response.send_message(
            f"⏰ Напомню <t:{int(due.timestamp())}:R>",
            ephemeral=True,
        )

    @app_commands.command(name="roleinfo", description="Информация о роли")
    @app_commands.describe(role="Роль")
    async def roleinfo(self, interaction: discord.Interaction, role: discord.Role):
        embed = make_embed(
            title=f"🎭 {role.name}",
            color=role.color if role.color.value else None,
            fields=[
                {"name": "ID", "value": f"`{role.id}`", "inline": True},
                {"name": "Участников", "value": f"**{len(role.members)}**", "inline": True},
                {"name": "Цвет", "value": f"`#{role.color.value:06x}`", "inline": True},
                {"name": "Позиция", "value": f"**{role.position}**", "inline": True},
                {"name": "Mentionable", "value": "Да" if role.mentionable else "Нет", "inline": True},
                {"name": "Hoisted", "value": "Да" if role.hoist else "Нет", "inline": True},
                {"name": "Создана", "value": f"<t:{int(role.created_at.timestamp())}:D>", "inline": True},
            ],
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="membercount", description="Количество участников")
    async def membercount(self, interaction: discord.Interaction):
        g = interaction.guild
        embed = make_embed(
            title="👥 Участники",
            description=f"**{g.member_count}** участников на сервере **{g.name}**",
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="random", description="Случайное число")
    @app_commands.describe(min_val="От", max_val="До")
    async def random_num(
        self,
        interaction: discord.Interaction,
        min_val: app_commands.Range[int, -1000000, 1000000],
        max_val: app_commands.Range[int, -1000000, 1000000],
    ):
        if min_val > max_val:
            await interaction.response.send_message("❌ min > max", ephemeral=True)
            return
        num = random.randint(min_val, max_val)
        await interaction.response.send_message(f"🎲 Случайное число: **{num}**")

    @app_commands.command(name="8ball", description="Магический шар")
    @app_commands.describe(question="Вопрос")
    async def eight_ball(self, interaction: discord.Interaction, question: str):
        answers = [
            "Да, определённо.", "Можешь быть уверен в этом.", "Без сомнения.", "Да.",
            "Скорее всего да.", "Спроси позже.", "Не могу сказать сейчас.", "Сфокусируйся и спроси снова.",
            "Нет.", "Определённо нет.", "Даже не думай.", "Мой ответ — нет.", "Сомневаюсь.",
        ]
        ans = random.choice(answers)
        embed = make_embed(
            title="🎱 Магический шар",
            fields=[
                {"name": "Вопрос", "value": question, "inline": False},
                {"name": "Ответ", "value": ans, "inline": False},
            ],
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="choose", description="Случайный выбор из вариантов")
    @app_commands.describe(option1="Вариант 1", option2="Вариант 2", option3="Вариант 3 (необязательно)", option4="Вариант 4 (необязательно)")
    async def choose(
        self,
        interaction: discord.Interaction,
        option1: str,
        option2: str,
        option3: Optional[str] = None,
        option4: Optional[str] = None,
    ):
        opts = [option1, option2]
        if option3:
            opts.append(option3)
        if option4:
            opts.append(option4)
        chosen = random.choice(opts)
        embed = make_embed(
            title="🎯 Случайный выбор",
            description=f"Я выбираю: **{chosen}**",
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(UtilsCog(bot))
