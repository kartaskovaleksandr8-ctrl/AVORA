# Cogs directory

Каждый файл здесь — это discord.py "cog" (модуль).

| Файл              | Что делает                                            |
|-------------------|--------------------------------------------------------|
| tickets.py        | Ticket Tool style тикеты с кнопками                    |
| voice.py          | VoiceMaster — авто-создание голосовых каналов          |
| reaction_roles.py | Выдача ролей по реакции/кнопке                         |
| moderation.py     | warn/mute/kick/ban + лог                               |
| leveling.py       | XP/уровни/награды/лидерборд                            |
| music.py          | Музыкальный плеер на yt-dlp + ffmpeg                   |
| welcome.py        | Welcome/Goodbye + авто-роль                            |
| automod.py        | Анти-спам/капс/ссылки/инвайты                          |
| giveaways.py      | Розыгрыши с кнопкой и автозавершением                  |
| utils.py          | userinfo/serverinfo/avatar/poll/remind/8ball и т.д.    |

Чтобы добавить новый cog, создайте `my_cog.py`:

```python
from discord.ext import commands
from utils.helpers import load_config, is_admin, make_embed


class MyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="hello")
    async def hello(self, interaction: discord.Interaction):
        await interaction.response.send_message("Привет!")


async def setup(bot: commands.Bot):
    await bot.add_cog(MyCog(bot))
```

Перезапустите бота — cog загрузится автоматически.
