"""
Welcome / Goodbye cog.

Sends a welcome message when a member joins, and a goodbye when they leave.
Configured via config.json or slash commands.
"""
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional

from utils.helpers import load_config, save_config, make_embed, is_admin


class WelcomeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        cfg = load_config()
        channel_id = cfg.get("welcome_channel_id")
        if not channel_id:
            return
        channel = member.guild.get_channel(int(channel_id))
        if not channel:
            return
        text = cfg.get(
            "welcome_message",
            "Добро пожаловать, {user} на сервер {server}! Ты наш {member_count}-й участник.",
        )
        msg = text.format(
            user=member.mention,
            server=member.guild.name,
            member_count=member.guild.member_count,
            username=member.name,
        )
        embed = make_embed(
            title="👋 Новенький!",
            description=msg,
            color=0x57F287,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(content=member.mention, embed=embed)
        except discord.HTTPException:
            pass

        # Auto-role for newcomers
        auto_role_id = cfg.get("autorole_id")
        if auto_role_id:
            role = member.guild.get_role(int(auto_role_id))
            if role:
                try:
                    await member.add_roles(role, reason="Auto-role")
                except discord.Forbidden:
                    pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        cfg = load_config()
        channel_id = cfg.get("goodbye_channel_id")
        if not channel_id:
            return
        channel = member.guild.get_channel(int(channel_id))
        if not channel:
            return
        text = cfg.get(
            "goodbye_message",
            "Прощай, {user}! Нас осталось {member_count}.",
        )
        msg = text.format(
            user=member.name,
            server=member.guild.name,
            member_count=member.guild.member_count,
            username=member.name,
        )
        embed = make_embed(
            title="😢 Ушёл",
            description=msg,
            color=0xED4245,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass

    welcome_group = app_commands.Group(name="welcome", description="Настройки приветствий")

    @welcome_group.command(name="channel", description="Установить канал для приветствий")
    @app_commands.describe(channel="Канал")
    @app_commands.default_permissions(manage_guild=True)
    async def welcome_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg["welcome_channel_id"] = str(channel.id)
        save_config(cfg)
        await interaction.response.send_message(f"✅ Канал приветствий: {channel.mention}", ephemeral=True)

    @welcome_group.command(name="message", description="Установить текст приветствия ({user}, {server}, {member_count}, {username})")
    @app_commands.default_permissions(manage_guild=True)
    async def welcome_message(self, interaction: discord.Interaction, message: str):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg["welcome_message"] = message
        save_config(cfg)
        await interaction.response.send_message("✅ Текст приветствия обновлён.", ephemeral=True)

    @welcome_group.command(name="test", description="Проверить приветствие")
    @app_commands.default_permissions(manage_guild=True)
    async def welcome_test(self, interaction: discord.Interaction):
        cfg = load_config()
        channel_id = cfg.get("welcome_channel_id")
        if not channel_id:
            await interaction.response.send_message("❌ Канал не настроен.", ephemeral=True)
            return
        channel = interaction.guild.get_channel(int(channel_id))
        if not channel:
            await interaction.response.send_message("❌ Канал не найден.", ephemeral=True)
            return
        text = cfg.get("welcome_message", "Добро пожаловать, {user}!")
        msg = text.format(
            user=interaction.user.mention,
            server=interaction.guild.name,
            member_count=interaction.guild.member_count,
            username=interaction.user.name,
        )
        embed = make_embed(title="👋 Новенький! (тест)", description=msg, color=0x57F287)
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        await channel.send(content=interaction.user.mention, embed=embed)
        await interaction.response.send_message("✅ Отправлено.", ephemeral=True)

    goodbye_group = app_commands.Group(name="goodbye", description="Настройки прощаний")

    @goodbye_group.command(name="channel", description="Установить канал для прощаний")
    @app_commands.default_permissions(manage_guild=True)
    async def goodbye_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg["goodbye_channel_id"] = str(channel.id)
        save_config(cfg)
        await interaction.response.send_message(f"✅ Канал прощаний: {channel.mention}", ephemeral=True)

    @goodbye_group.command(name="message", description="Установить текст прощания")
    @app_commands.default_permissions(manage_guild=True)
    async def goodbye_message(self, interaction: discord.Interaction, message: str):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg["goodbye_message"] = message
        save_config(cfg)
        await interaction.response.send_message("✅ Текст прощания обновлён.", ephemeral=True)

    @app_commands.command(name="autorole", description="Установить авто-роль для новичков")
    @app_commands.describe(role="Роль (или 'none' чтобы убрать)")
    @app_commands.default_permissions(manage_roles=True)
    async def autorole(self, interaction: discord.Interaction, role: Optional[discord.Role] = None):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        if role is None:
            cfg.pop("autorole_id", None)
            await interaction.response.send_message("✅ Авто-роль убрана.", ephemeral=True)
        else:
            cfg["autorole_id"] = str(role.id)
            await interaction.response.send_message(f"✅ Авто-роль: {role.mention}", ephemeral=True)
        save_config(cfg)


async def setup(bot: commands.Bot):
    await bot.add_cog(WelcomeCog(bot))
