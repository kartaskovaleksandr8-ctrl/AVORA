"""
Music cog — queue-based music player using yt-dlp.

Slash commands:
  /play <query>
  /pause
  /resume
  /skip
  /stop
  /queue
  /volume <0-100>
  /nowplaying
"""
import discord
from discord import app_commands
from discord.ext import commands, tasks
from typing import Optional
import asyncio
import yt_dlp
import logging
import os
import sys
from pathlib import Path

log = logging.getLogger("avora_bot.music")

ytdl_format_options = {
    "format": "bestaudio/best",
    "outtmpl": "%(extractor)s-%(id)s-%(title)s.%(ext)s",
    "restrictfilenames": True,
    "noplaylist": True,
    "nocheckcertificate": True,
    "ignoreerrors": False,
    "logtostderr": False,
    "quiet": True,
    "no_warnings": True,
    "default_search": "auto",
    "source_address": "0.0.0.0",
    "usenetrc": False,
}

ffmpeg_options = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}

# Locate ffmpeg.exe — we ship it bundled next to python.exe for the
# embedded distribution. On dev machines it should be in PATH.
def _find_ffmpeg() -> Optional[str]:
    # 1. python.exe directory (bundled in production)
    bot_root = Path(__file__).resolve().parent
    candidates = [
        bot_root / "python" / "ffmpeg.exe",       # bundled embeddable Python
        bot_root / "ffmpeg.exe",                   # next to bot.py
        bot_root.parent / "python" / "ffmpeg.exe",
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    # 2. PATH (dev mode)
    return None  # discord.py will use PATH fallback

FFMPEG_PATH = _find_ffmpeg()
if FFMPEG_PATH:
    log.info("FFmpeg found at: %s", FFMPEG_PATH)

ytdl = yt_dlp.YoutubeDL(ytdl_format_options)


class YTDLSource(discord.PCMVolumeTransformer):
    def __init__(self, source: discord.FFmpegPCMAudio, *, data: dict, volume: float = 0.5):
        super().__init__(source, volume)
        self.data = data
        self.title = data.get("title", "Unknown")
        self.url = data.get("webpage_url", "")
        self.duration = data.get("duration", 0)
        self.thumbnail = data.get("thumbnail", "")

    @classmethod
    async def from_url(cls, url: str, loop: asyncio.AbstractEventLoop) -> "YTDLSource":
        loop = loop or asyncio.get_event_loop()
        data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=False))
        if "entries" in data:
            data = data["entries"][0]
        # Use bundled ffmpeg if available
        ffmpeg_kwargs = dict(ffmpeg_options)
        if FFMPEG_PATH:
            ffmpeg_kwargs["executable"] = FFMPEG_PATH
        return cls(
            discord.FFmpegPCMAudio(data["url"], **ffmpeg_kwargs),
            data=data,
        )


class GuildMusicState:
    def __init__(self, guild_id: int):
        self.guild_id = guild_id
        self.queue: list[dict] = []
        self.current: Optional[YTDLSource] = None
        self.volume: float = 0.5
        self.text_channel_id: Optional[int] = None
        self.loop_mode: str = "off"  # off | song | queue


class MusicCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.states: dict[int, GuildMusicState] = {}

    def get_state(self, guild_id: int) -> GuildMusicState:
        if guild_id not in self.states:
            self.states[guild_id] = GuildMusicState(guild_id)
        return self.states[guild_id]

    async def _play_next(self, guild: discord.Guild):
        state = self.get_state(guild.id)
        if state.loop_mode == "song" and state.current:
            # Re-play current
            try:
                source = await YTDLSource.from_url(state.current.url, self.bot.loop)
                source.volume = state.volume
                state.current = source
                if guild.voice_client:
                    guild.voice_client.play(source, after=lambda e: asyncio.run_coroutine_threadsafe(self._on_song_end(guild, e), self.bot.loop))
                return
            except Exception as e:
                log.error("Loop song error: %s", e)

        if not state.queue:
            state.current = None
            return

        track = state.queue.pop(0)
        try:
            source = await YTDLSource.from_url(track["url"], self.bot.loop)
            source.volume = state.volume
            state.current = source
            if not guild.voice_client:
                log.error("No voice client in guild %s — track not played", guild.id)
                return
            guild.voice_client.play(source, after=lambda e: asyncio.run_coroutine_threadsafe(self._on_song_end(guild, e), self.bot.loop))

            # Send now playing
            channel = guild.get_channel(state.text_channel_id) if state.text_channel_id else None
            if channel:
                from utils.helpers import make_embed
                embed = make_embed(
                    title="▶️ Сейчас играет",
                    description=f"**[{source.title}]({source.url})**",
                    color=0x1DB954,
                )
                if source.thumbnail:
                    embed.set_thumbnail(url=source.thumbnail)
                try:
                    await channel.send(embed=embed, delete_after=30)
                except discord.HTTPException:
                    pass
        except discord.ClientException as e:
            # Most common: FFmpeg not found
            log.error("FFmpeg error: %s", e)
            channel = guild.get_channel(state.text_channel_id) if state.text_channel_id else None
            if channel:
                try:
                    await channel.send(
                        "❌ Не удалось воспроизвести трек. Скорее всего не установлен **ffmpeg**. "
                        "Скачайте ffmpeg.exe и положите его в папку с приложением или в PATH.",
                        delete_after=30,
                    )
                except discord.HTTPException:
                    pass
        except Exception as e:
            log.error("Play error: %s", e)
            channel = guild.get_channel(state.text_channel_id) if state.text_channel_id else None
            if channel:
                try:
                    await channel.send(f"❌ Ошибка воспроизведения: {e}", delete_after=30)
                except discord.HTTPException:
                    pass

    async def _on_song_end(self, guild: discord.Guild, error: Optional[Exception]):
        if error:
            log.error("Player error: %s", error)
        state = self.get_state(guild.id)
        if state is None:
            return
        if state.loop_mode == "queue" and state.current:
            state.queue.append({"url": state.current.url, "title": state.current.title})
        state.current = None
        await self._play_next(guild)
        if not state.queue and not state.current:
            # Disconnect after 5 min idle
            await asyncio.sleep(300)
            if guild.voice_client and not state.queue and not state.current:
                try:
                    await guild.voice_client.disconnect()
                except discord.HTTPException:
                    pass

    @app_commands.command(name="play", description="Включить музыку (название или URL)")
    @app_commands.describe(query="Название песни или ссылка YouTube/Spotify")
    async def play(self, interaction: discord.Interaction, query: str):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message("❌ Вы должны быть в голосовом канале.", ephemeral=True)
            return

        voice_channel = interaction.user.voice.channel
        if not interaction.guild.voice_client:
            try:
                vc = await voice_channel.connect()
            except discord.ClientException:
                await interaction.response.send_message("❌ Не удалось подключиться.", ephemeral=True)
                return
        else:
            vc = interaction.guild.voice_client
            if vc.channel != voice_channel:
                await vc.move_to(voice_channel)

        state = self.get_state(interaction.guild.id)
        state.text_channel_id = interaction.channel.id

        await interaction.response.defer()
        try:
            # Extract info
            loop = self.bot.loop
            data = await loop.run_in_executor(None, lambda: ytdl.extract_info(query, download=False))
            if "entries" in data:
                entries = data["entries"]
                if not entries:
                    await interaction.followup.send("❌ Ничего не найдено.", ephemeral=True)
                    return
                added = 0
                for e in entries[:50]:
                    if e:
                        state.queue.append({"url": e.get("webpage_url", e.get("url")), "title": e.get("title", "Unknown")})
                        added += 1
                await interaction.followup.send(f"✅ Добавлено в очередь: **{added}** треков")
            else:
                state.queue.append({"url": data.get("webpage_url", data.get("url")), "title": data.get("title", "Unknown")})
                await interaction.followup.send(f"✅ Добавлено: **{data.get('title', 'Unknown')}**")
        except Exception as e:
            await interaction.followup.send(f"❌ Ошибка поиска: {e}", ephemeral=True)
            return

        if not state.current and not vc.is_playing():
            await self._play_next(interaction.guild)

    @app_commands.command(name="pause", description="Пауза")
    async def pause(self, interaction: discord.Interaction):
        vc = interaction.guild.voice_client
        if not vc or not vc.is_playing():
            await interaction.response.send_message("❌ Ничего не играет.", ephemeral=True)
            return
        vc.pause()
        await interaction.response.send_message("⏸️ Пауза.")

    @app_commands.command(name="resume", description="Продолжить")
    async def resume(self, interaction: discord.Interaction):
        vc = interaction.guild.voice_client
        if not vc or not vc.is_paused():
            await interaction.response.send_message("❌ Не на паузе.", ephemeral=True)
            return
        vc.resume()
        await interaction.response.send_message("▶️ Продолжаем.")

    @app_commands.command(name="skip", description="Пропустить трек")
    async def skip(self, interaction: discord.Interaction):
        vc = interaction.guild.voice_client
        if not vc or not vc.is_playing():
            await interaction.response.send_message("❌ Ничего не играет.", ephemeral=True)
            return
        vc.stop()
        await interaction.response.send_message("⏭️ Пропущено.")

    @app_commands.command(name="stop", description="Остановить и очистить очередь")
    async def stop(self, interaction: discord.Interaction):
        vc = interaction.guild.voice_client
        state = self.get_state(interaction.guild.id)
        state.queue.clear()
        state.current = None
        if vc:
            vc.stop()
            try:
                await vc.disconnect()
            except discord.HTTPException:
                pass
        await interaction.response.send_message("⏹️ Остановлено.")

    @app_commands.command(name="queue", description="Показать очередь")
    async def queue(self, interaction: discord.Interaction):
        state = self.get_state(interaction.guild.id)
        if not state.queue and not state.current:
            await interaction.response.send_message("Очередь пуста.", ephemeral=True)
            return
        from utils.helpers import make_embed
        embed = make_embed(title="🎵 Очередь")
        if state.current:
            embed.add_field(name="▶️ Сейчас играет", value=f"**{state.current.title}**", inline=False)
        if state.queue:
            lines = []
            for i, t in enumerate(state.queue[:15], start=1):
                lines.append(f"**{i}.** {t['title'][:80]}")
            embed.add_field(name=f"Далее ({len(state.queue)})", value="\n".join(lines), inline=False)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="volume", description="Громкость (0-100)")
    @app_commands.describe(level="0-100")
    async def volume(self, interaction: discord.Interaction, level: app_commands.Range[int, 0, 100]):
        state = self.get_state(interaction.guild.id)
        state.volume = level / 100
        if state.current:
            state.current.volume = state.volume
        await interaction.response.send_message(f"🔊 Громкость: **{level}%**", ephemeral=True)

    @app_commands.command(name="nowplaying", description="Что играет сейчас")
    async def nowplaying(self, interaction: discord.Interaction):
        state = self.get_state(interaction.guild.id)
        if not state.current:
            await interaction.response.send_message("❌ Ничего не играет.", ephemeral=True)
            return
        from utils.helpers import make_embed
        embed = make_embed(
            title="▶️ Сейчас играет",
            description=f"**[{state.current.title}]({state.current.url})**\nГромкость: {int(state.volume*100)}%",
            color=0x1DB954,
        )
        if state.current.thumbnail:
            embed.set_thumbnail(url=state.current.thumbnail)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="loop", description="Зациклить: off / song / queue")
    @app_commands.describe(mode="off / song / queue")
    async def loop(self, interaction: discord.Interaction, mode: str):
        if mode not in ("off", "song", "queue"):
            await interaction.response.send_message("❌ Допустимо: off, song, queue.", ephemeral=True)
            return
        state = self.get_state(interaction.guild.id)
        state.loop_mode = mode
        await interaction.response.send_message(f"🔁 Loop: **{mode}**")


async def setup(bot: commands.Bot):
    await bot.add_cog(MusicCog(bot))
