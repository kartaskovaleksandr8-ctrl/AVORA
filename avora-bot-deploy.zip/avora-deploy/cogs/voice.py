"""
VoiceMaster cog — Voice channel creation (VoiceMaster/Ticket Tool style).

User joins a "trigger" channel → bot creates a personal voice channel for them
and moves them into it. When empty, the personal channel is auto-deleted.

Commands (slash):
  /voicemaster setup <trigger_channel> [category]  — enable VoiceMaster
  /voicemaster disable                              — disable
  /voicemaster name <template>                      — set name template ({user}, {server})
  /voicemaster lock|unlock                          — lock/unlock current channel
  /voicemaster limit <number>                       — set user limit
  /voicemaster rename <name>                        — rename current channel
  /voicemaster transfer <user>                      — transfer ownership
"""
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional

from utils.helpers import load_config, save_config, load_json, save_json, make_embed, is_admin

DB_FILE = "voice_master.json"


class VoiceMasterCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.owned_channels: dict[int, int] = {}  # channel_id -> owner_id

    # ---------- events ----------
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
        cfg = load_config()
        vm_cfg = cfg.get("voice_master", {})
        if not vm_cfg.get("enabled"):
            return

        trigger_id = vm_cfg.get("trigger_channel_id")
        if not trigger_id:
            return
        trigger_id = int(trigger_id)

        # User joined trigger channel
        if after.channel and after.channel.id == trigger_id:
            await self._create_personal_channel(member, vm_cfg)

        # User left a personal channel -> check empty
        if before.channel and before.channel.id != trigger_id:
            db = load_json(DB_FILE, {"channels": {}})
            channels = db.get("channels", {})
            ch_info = channels.get(str(before.channel.id))
            if ch_info:
                # If channel empty -> delete
                if len(before.channel.members) == 0:
                    try:
                        await before.channel.delete(reason="VoiceMaster: empty channel")
                    except discord.HTTPException:
                        pass
                    channels.pop(str(before.channel.id), None)
                    db["channels"] = channels
                    save_json(DB_FILE, db)
                else:
                    # If owner left -> transfer to next member
                    if ch_info.get("owner_id") == str(member.id):
                        new_owner = before.channel.members[0]
                        ch_info["owner_id"] = str(new_owner.id)
                        channels[str(before.channel.id)] = ch_info
                        db["channels"] = channels
                        save_json(DB_FILE, db)
                        try:
                            await before.channel.edit(name=f"🔊 {new_owner.display_name}'s channel")
                        except discord.HTTPException:
                            pass

    async def _create_personal_channel(self, member: discord.Member, vm_cfg: dict):
        guild = member.guild
        template = vm_cfg.get("name_template", "🔊 {user}'s channel")
        name = template.format(user=member.display_name, server=guild.name, username=member.name)[:100]

        category_id = vm_cfg.get("category_id")
        category = guild.get_channel(int(category_id)) if category_id else None

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=True, connect=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, connect=True, manage_channels=True, move_members=True),
            member: discord.PermissionOverwrite(
                view_channel=True, connect=True, manage_channels=True, move_members=True, mute_members=True, deafen_members=True
            ),
        }

        try:
            channel = await guild.create_voice_channel(
                name,
                category=category if isinstance(category, discord.CategoryChannel) else None,
                overwrites=overwrites,
            )
            await member.move_to(channel, reason="VoiceMaster")
        except discord.HTTPException:
            return

        db = load_json(DB_FILE, {"channels": {}})
        db.setdefault("channels", {})[str(channel.id)] = {
            "owner_id": str(member.id),
            "owner_name": str(member),
            "guild_id": str(guild.id),
            "created_at": member.joined_at.isoformat() if member.joined_at else None,
        }
        save_json(DB_FILE, db)
        self.owned_channels[channel.id] = member.id

    # ---------- slash commands ----------
    vm_group = app_commands.Group(name="voicemaster", description="VoiceMaster — личные голосовые каналы")

    @vm_group.command(name="setup", description="Включить VoiceMaster (выбрать триггер-канал)")
    @app_commands.describe(
        trigger_channel="Канал, в который нужно зайти для создания личного канала",
        category="Категория, в которой создавать личные каналы (необязательно)",
    )
    @app_commands.default_permissions(manage_guild=True)
    async def vm_setup(
        self,
        interaction: discord.Interaction,
        trigger_channel: discord.VoiceChannel,
        category: Optional[discord.CategoryChannel] = None,
    ):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg.setdefault("voice_master", {})
        cfg["voice_master"]["enabled"] = True
        cfg["voice_master"]["trigger_channel_id"] = str(trigger_channel.id)
        if category:
            cfg["voice_master"]["category_id"] = str(category.id)
        save_config(cfg)
        await interaction.response.send_message(
            f"✅ VoiceMaster включён. Триггер: {trigger_channel.mention}"
            + (f"\nКатегория: {category.name}" if category else ""),
            ephemeral=True,
        )

    @vm_group.command(name="disable", description="Отключить VoiceMaster")
    @app_commands.default_permissions(manage_guild=True)
    async def vm_disable(self, interaction: discord.Interaction):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg.setdefault("voice_master", {})["enabled"] = False
        save_config(cfg)
        await interaction.response.send_message("✅ VoiceMaster отключён.", ephemeral=True)

    @vm_group.command(name="name", description="Установить шаблон имени канала ({user}, {server}, {username})")
    @app_commands.describe(template="Шаблон, например: 🔊 {user}'s channel")
    @app_commands.default_permissions(manage_guild=True)
    async def vm_name(self, interaction: discord.Interaction, template: str):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message("❌ Недостаточно прав.", ephemeral=True)
            return
        cfg.setdefault("voice_master", {})["name_template"] = template
        save_config(cfg)
        await interaction.response.send_message(f"✅ Шаблон имени: `{template}`", ephemeral=True)

    @vm_group.command(name="lock", description="Закрыть текущий голосовой канал (только для владельца)")
    async def vm_lock(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message("❌ Вы не в голосовом канале.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"channels": {}})
        ch_info = db.get("channels", {}).get(str(interaction.user.voice.channel.id))
        if not ch_info or ch_info.get("owner_id") != str(interaction.user.id):
            await interaction.response.send_message("❌ Вы не владелец этого канала.", ephemeral=True)
            return
        overwrites = interaction.user.voice.channel.overwrites
        overwrites[interaction.guild.default_role] = discord.PermissionOverwrite(
            view_channel=True, connect=False
        )
        await interaction.user.voice.channel.edit(overwrites=overwrites)
        await interaction.response.send_message("🔒 Канал закрыт.", ephemeral=True)

    @vm_group.command(name="unlock", description="Открыть текущий голосовой канал")
    async def vm_unlock(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message("❌ Вы не в голосовом канале.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"channels": {}})
        ch_info = db.get("channels", {}).get(str(interaction.user.voice.channel.id))
        if not ch_info or ch_info.get("owner_id") != str(interaction.user.id):
            await interaction.response.send_message("❌ Вы не владелец этого канала.", ephemeral=True)
            return
        overwrites = interaction.user.voice.channel.overwrites
        overwrites[interaction.guild.default_role] = discord.PermissionOverwrite(
            view_channel=True, connect=True
        )
        await interaction.user.voice.channel.edit(overwrites=overwrites)
        await interaction.response.send_message("🔓 Канал открыт.", ephemeral=True)

    @vm_group.command(name="limit", description="Установить лимит пользователей (0 = без лимита)")
    @app_commands.describe(limit="Максимум пользователей (0-99)")
    async def vm_limit(self, interaction: discord.Interaction, limit: app_commands.Range[int, 0, 99]):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message("❌ Вы не в голосовом канале.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"channels": {}})
        ch_info = db.get("channels", {}).get(str(interaction.user.voice.channel.id))
        if not ch_info or ch_info.get("owner_id") != str(interaction.user.id):
            await interaction.response.send_message("❌ Вы не владелец этого канала.", ephemeral=True)
            return
        await interaction.user.voice.channel.edit(user_limit=limit)
        await interaction.response.send_message(f"✅ Лимит: {limit}", ephemeral=True)

    @vm_group.command(name="rename", description="Переименовать текущий голосовой канал")
    @app_commands.describe(name="Новое имя")
    async def vm_rename(self, interaction: discord.Interaction, name: str):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message("❌ Вы не в голосовом канале.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"channels": {}})
        ch_info = db.get("channels", {}).get(str(interaction.user.voice.channel.id))
        if not ch_info or ch_info.get("owner_id") != str(interaction.user.id):
            await interaction.response.send_message("❌ Вы не владелец этого канала.", ephemeral=True)
            return
        await interaction.user.voice.channel.edit(name=name[:100])
        await interaction.response.send_message(f"✅ Канал переименован: `{name}`", ephemeral=True)

    @vm_group.command(name="transfer", description="Передать владение каналом другому участнику")
    @app_commands.describe(user="Новый владелец")
    async def vm_transfer(self, interaction: discord.Interaction, user: discord.Member):
        if not interaction.user.voice or not interaction.user.voice.channel:
            await interaction.response.send_message("❌ Вы не в голосовом канале.", ephemeral=True)
            return
        if user not in interaction.user.voice.channel.members:
            await interaction.response.send_message("❌ Пользователь не в вашем канале.", ephemeral=True)
            return
        db = load_json(DB_FILE, {"channels": {}})
        ch_info = db.get("channels", {}).get(str(interaction.user.voice.channel.id))
        if not ch_info or ch_info.get("owner_id") != str(interaction.user.id):
            await interaction.response.send_message("❌ Вы не владелец этого канала.", ephemeral=True)
            return
        ch_info["owner_id"] = str(user.id)
        ch_info["owner_name"] = str(user)
        db["channels"][str(interaction.user.voice.channel.id)] = ch_info
        save_json(DB_FILE, db)
        await interaction.response.send_message(f"✅ Владение передано: {user.mention}", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(VoiceMasterCog(bot))
