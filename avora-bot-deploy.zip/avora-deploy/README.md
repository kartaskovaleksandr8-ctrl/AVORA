# AVORA BOT — Cloud Deployment Package

Этот пакет содержит всё необходимое для размещения бота на бесплатном облаке 24/7.

## 📦 Содержимое

```
avora-deploy/
├── bot.py              # Точка входа (поддержка env vars)
├── cogs/               # Модули бота (10 файлов)
├── api/                # FastAPI bridge
├── utils/              # Утилиты
├── database/           # JSON-хранилище (создаётся автоматически)
├── requirements.txt    # Python-зависимости
├── render.yaml         # Конфиг для Render.com
├── Dockerfile          # Альтернативный способ (Docker)
├── Procfile            # Альтернативный способ (Heroku/Railway)
└── .gitignore
```

## 🚀 Размещение на Render.com (бесплатно, 24/7)

### Шаг 1: GitHub (2 минуты)
1. Зарегистрируйтесь на https://github.com (если ещё нет аккаунта)
2. Создайте новый репозиторий: https://github.com/new
   - Name: `avora-bot`
   - Private (рекомендуется)
   - НЕ добавляйте README/license/gitignore
3. Загрузите все файлы из этой папки в репозиторий
   (На GitHub: "uploading an existing file" → перетащите файлы)

### Шаг 2: Render.com (5 минут)
1. Зарегистрируйтесь на https://render.com через GitHub
2. Dashboard → **New +** → **Background Worker**
3. Подключите ваш GitHub репозиторий `avora-bot`
4. Настройки:
   - **Name:** avora-bot
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python bot.py`
   - **Instance Type:** Free

### Шаг 3: Environment Variables (3 минуты)
В разделе **Environment** добавьте переменные:

| Key | Value |
|-----|-------|
| `BOT_TOKEN` | ваш токен бота из Discord Developer Portal |
| `GUILD_ID` | ID вашего Discord-сервера |
| `OWNER_DISCORD_ID` | ваш Discord ID |
| `ADMIN_ROLE_ID` | ID роли администратора |
| `APPLICATION_ID` | ID приложения из Discord Developer Portal |
| `CLIENT_SECRET` | client secret из Discord Developer Portal |

### Шаг 4: Запуск (1 минута)
1. Нажмите **Create Background Worker**
2. Ждите 2-3 минуты (Render скачивает зависимости)
3. В разделе **Logs** убедитесь что видите: `BOT IS READY`
4. Бот онлайн 24/7!

### Шаг 5: Подключение приложения
1. В Render вверху страницы сервиса будет URL вида:
   `https://avora-bot-xxxx.onrender.com`
2. Скопируйте этот URL
3. Откройте AVORA BOT на ПК → Настройки → «URL удалённого бота»
4. Вставьте URL → Сохранить
5. Перезапустите приложение

## ✅ Готово!

Теперь:
- Бот работает 24/7 на Render (бесплатно)
- Приложение на ПК подключается к нему автоматически
- ПК можно выключать — бот остаётся онлайн
- Multiple admins видят одни и те же данные

## ⚠️ Ограничения бесплатного тарифа Render

- 750 часов/месяц (хватает на 24/7 для одного воркера)
- Воркер "засыпает" через 15 минут без активности
  - Для Discord-бота это не проблема — бот держит WebSocket соединение
  - Discord шлет heartbeat каждые 30 сек → воркер не засыпает
- 512 MB RAM (достаточно для бота)

## 🔧 Альтернатива: Railway.app

Если Render не работает, попробуйте Railway:
1. https://railway.app → New Project → Deploy from GitHub
2. Выберите репозиторий
3. Variables → добавьте те же env vars
4. Railway даст $5 кредита/мес (хватает на 500 часов)

## 📝 Лицензия

MIT — делайте что хотите.
